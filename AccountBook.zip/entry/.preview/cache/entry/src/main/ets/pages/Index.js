import router from '@ohos:router';
import { ImageList } from '@bundle:com.example.accountbook/entry/ets/bean/AccountList';
import AccountTable from '@bundle:com.example.accountbook/entry/ets/database/AccountTable';
import CommonConstants from '@bundle:com.example.accountbook/entry/ets/database/CommonConstants';
import Logger from '@bundle:com.example.accountbook/entry/ets/utils/Logger';
import { DialogComponent } from '@bundle:com.example.accountbook/entry/ets/pages/DialogComponent';
import systemDateTime from '@ohos:systemDateTime';
import dateHelper from '@bundle:com.example.accountbook/entry/ets/utils/Logger';
//声明侧滑栏目类
class showingColumn {
    constructor(data, h_scroller) {
        this.data = data;
        this.h_scroller = h_scroller;
    }
}
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__title = this.createLocalStorageProp("title", "口袋记账本", "title");
        this.settings = new RenderingContextSettings(true);
        this.context = new CanvasRenderingContext2D(this.settings);
        this.offContext = new OffscreenCanvasRenderingContext2D(600, 600, this.settings);
        this.__xPos = new ObservedPropertyObjectPU(new Array(30, 80, 130, 180, 230, 280, 330), this, "xPos");
        this.__yPos = new ObservedPropertyObjectPU(new Array(1, 1, 1, 1, 1, 1, 1), this, "yPos");
        this.__daySum = new ObservedPropertySimplePU(0, this, "daySum");
        this.__monSum = new ObservedPropertySimplePU(0, this, "monSum");
        this.__refresh = new ObservedPropertySimplePU(1, this, "refresh");
        this.__scale2 = new ObservedPropertySimplePU(1, this, "scale2");
        this.__opacity2 = new ObservedPropertySimplePU(1, this, "opacity2");
        this.__switchLeft = new ObservedPropertySimplePU(false, this, "switchLeft");
        this.__accounts = new ObservedPropertyObjectPU([], this, "accounts");
        this.__message = new ObservedPropertySimplePU('hello', this, "message");
        this.__isEditing = new ObservedPropertySimplePU(false, this, "isEditing");
        this.__isInsert = new ObservedPropertySimplePU(false, this, "isInsert");
        this.__index = new ObservedPropertySimplePU(-1, this, "index");
        this.__isDragging = new ObservedPropertySimplePU(false, this, "isDragging");
        this.__today_income = new ObservedPropertySimplePU(-1, this, "today_income");
        this.__today_outcome = new ObservedPropertySimplePU(-1, this, "today_outcome");
        this.__searchText = new ObservedPropertySimplePU('', this, "searchText");
        this.__newAccount = new ObservedPropertyObjectPU({
            id: 0,
            accountType: 0,
            typeText: '',
            amount: 0,
            day: '',
            year: '',
            month: '',
            reminder: '',
        }, this, "newAccount");
        this.AccountTable = new AccountTable(() => { });
        this.deleteList = [];
        this.searchController = new SearchController();
        this.scroller = new Scroller();
        this.openedDeleteData = null;
        this.horizontal_scroller = new Scroller();
        this.downX = 0;
        this.deleteWidth = 100;
        this.dialogController = new CustomDialogController({
            builder: () => {
                let jsDialog = new DialogComponent(this, {
                    isInsert: this.__isInsert,
                    newAccount: this.__newAccount,
                    confirm: (isInsert, newAccount) => this.accept(isInsert, newAccount)
                });
                jsDialog.setController(this.
                /*页面跳转-controller*/
                dialogController);
                ViewPU.create(jsDialog);
            },
            customStyle: true,
            alignment: DialogAlignment.Bottom
        }, this);
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.settings !== undefined) {
            this.settings = params.settings;
        }
        if (params.context !== undefined) {
            this.context = params.context;
        }
        if (params.offContext !== undefined) {
            this.offContext = params.offContext;
        }
        if (params.xPos !== undefined) {
            this.xPos = params.xPos;
        }
        if (params.yPos !== undefined) {
            this.yPos = params.yPos;
        }
        if (params.daySum !== undefined) {
            this.daySum = params.daySum;
        }
        if (params.monSum !== undefined) {
            this.monSum = params.monSum;
        }
        if (params.refresh !== undefined) {
            this.refresh = params.refresh;
        }
        if (params.scale2 !== undefined) {
            this.scale2 = params.scale2;
        }
        if (params.opacity2 !== undefined) {
            this.opacity2 = params.opacity2;
        }
        if (params.switchLeft !== undefined) {
            this.switchLeft = params.switchLeft;
        }
        if (params.accounts !== undefined) {
            this.accounts = params.accounts;
        }
        if (params.message !== undefined) {
            this.message = params.message;
        }
        if (params.isEditing !== undefined) {
            this.isEditing = params.isEditing;
        }
        if (params.isInsert !== undefined) {
            this.isInsert = params.isInsert;
        }
        if (params.index !== undefined) {
            this.index = params.index;
        }
        if (params.isDragging !== undefined) {
            this.isDragging = params.isDragging;
        }
        if (params.today_income !== undefined) {
            this.today_income = params.today_income;
        }
        if (params.today_outcome !== undefined) {
            this.today_outcome = params.today_outcome;
        }
        if (params.searchText !== undefined) {
            this.searchText = params.searchText;
        }
        if (params.newAccount !== undefined) {
            this.newAccount = params.newAccount;
        }
        if (params.AccountTable !== undefined) {
            this.AccountTable = params.AccountTable;
        }
        if (params.deleteList !== undefined) {
            this.deleteList = params.deleteList;
        }
        if (params.searchController !== undefined) {
            this.searchController = params.searchController;
        }
        if (params.scroller !== undefined) {
            this.scroller = params.scroller;
        }
        if (params.openedDeleteData !== undefined) {
            this.openedDeleteData = params.openedDeleteData;
        }
        if (params.horizontal_scroller !== undefined) {
            this.horizontal_scroller = params.horizontal_scroller;
        }
        if (params.downX !== undefined) {
            this.downX = params.downX;
        }
        if (params.deleteWidth !== undefined) {
            this.deleteWidth = params.deleteWidth;
        }
        if (params.dialogController !== undefined) {
            this.dialogController = params.dialogController;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__xPos.purgeDependencyOnElmtId(rmElmtId);
        this.__yPos.purgeDependencyOnElmtId(rmElmtId);
        this.__daySum.purgeDependencyOnElmtId(rmElmtId);
        this.__monSum.purgeDependencyOnElmtId(rmElmtId);
        this.__refresh.purgeDependencyOnElmtId(rmElmtId);
        this.__scale2.purgeDependencyOnElmtId(rmElmtId);
        this.__opacity2.purgeDependencyOnElmtId(rmElmtId);
        this.__switchLeft.purgeDependencyOnElmtId(rmElmtId);
        this.__accounts.purgeDependencyOnElmtId(rmElmtId);
        this.__message.purgeDependencyOnElmtId(rmElmtId);
        this.__isEditing.purgeDependencyOnElmtId(rmElmtId);
        this.__isInsert.purgeDependencyOnElmtId(rmElmtId);
        this.__index.purgeDependencyOnElmtId(rmElmtId);
        this.__isDragging.purgeDependencyOnElmtId(rmElmtId);
        this.__today_income.purgeDependencyOnElmtId(rmElmtId);
        this.__today_outcome.purgeDependencyOnElmtId(rmElmtId);
        this.__searchText.purgeDependencyOnElmtId(rmElmtId);
        this.__newAccount.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__xPos.aboutToBeDeleted();
        this.__yPos.aboutToBeDeleted();
        this.__daySum.aboutToBeDeleted();
        this.__monSum.aboutToBeDeleted();
        this.__title.aboutToBeDeleted();
        this.__refresh.aboutToBeDeleted();
        this.__scale2.aboutToBeDeleted();
        this.__opacity2.aboutToBeDeleted();
        this.__switchLeft.aboutToBeDeleted();
        this.__accounts.aboutToBeDeleted();
        this.__message.aboutToBeDeleted();
        this.__isEditing.aboutToBeDeleted();
        this.__isInsert.aboutToBeDeleted();
        this.__index.aboutToBeDeleted();
        this.__isDragging.aboutToBeDeleted();
        this.__today_income.aboutToBeDeleted();
        this.__today_outcome.aboutToBeDeleted();
        this.__searchText.aboutToBeDeleted();
        this.__newAccount.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get xPos() {
        return this.__xPos.get();
    }
    set xPos(newValue) {
        this.__xPos.set(newValue);
    }
    get yPos() {
        return this.__yPos.get();
    }
    set yPos(newValue) {
        this.__yPos.set(newValue);
    }
    get daySum() {
        return this.__daySum.get();
    }
    set daySum(newValue) {
        this.__daySum.set(newValue);
    }
    get monSum() {
        return this.__monSum.get();
    }
    set monSum(newValue) {
        this.__monSum.set(newValue);
    }
    get title() {
        return this.__title.get();
    }
    set title(newValue) {
        this.__title.set(newValue);
    }
    get refresh() {
        return this.__refresh.get();
    }
    set refresh(newValue) {
        this.__refresh.set(newValue);
    }
    get scale2() {
        return this.__scale2.get();
    }
    set scale2(newValue) {
        this.__scale2.set(newValue);
    }
    get opacity2() {
        return this.__opacity2.get();
    }
    set opacity2(newValue) {
        this.__opacity2.set(newValue);
    }
    get switchLeft() {
        return this.__switchLeft.get();
    }
    set switchLeft(newValue) {
        this.__switchLeft.set(newValue);
    }
    get accounts() {
        return this.__accounts.get();
    }
    set accounts(newValue) {
        this.__accounts.set(newValue);
    }
    get message() {
        return this.__message.get();
    }
    set message(newValue) {
        this.__message.set(newValue);
    }
    get isEditing() {
        return this.__isEditing.get();
    }
    set isEditing(newValue) {
        this.__isEditing.set(newValue);
    }
    get isInsert() {
        return this.__isInsert.get();
    }
    set isInsert(newValue) {
        this.__isInsert.set(newValue);
    }
    get index() {
        return this.__index.get();
    }
    set index(newValue) {
        this.__index.set(newValue);
    }
    get isDragging() {
        return this.__isDragging.get();
    }
    set isDragging(newValue) {
        this.__isDragging.set(newValue);
    }
    get today_income() {
        return this.__today_income.get();
    }
    set today_income(newValue) {
        this.__today_income.set(newValue);
    }
    get today_outcome() {
        return this.__today_outcome.get();
    }
    set today_outcome(newValue) {
        this.__today_outcome.set(newValue);
    }
    get searchText() {
        return this.__searchText.get();
    }
    set searchText(newValue) {
        this.__searchText.set(newValue);
    }
    get newAccount() {
        return this.__newAccount.get();
    }
    set newAccount(newValue) {
        this.__newAccount.set(newValue);
    }
    CustomItem(item, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Scroll.create(item.h_scroller);
            Scroll.debugLine("pages/Index.ets(75:5)");
            Scroll.scrollable(ScrollDirection.Horizontal);
            Scroll.scrollBar(BarState.Off);
            Scroll.onTouch((event) => {
                console.info("###Touch me!!");
                // 判断是否有打开删除组件，有则关闭
                if (this.openedDeleteData != null && this.openedDeleteData != item) {
                    console.info("###Try to slide back");
                    this.openedDeleteData.h_scroller.scrollTo({ xOffset: 0, yOffset: 0,
                        animation: { duration: 100, curve: Curve.Linear } });
                }
                // 根据触摸类型判断
                switch (event.type) {
                    case TouchType.Down: // 触摸按下
                        // 记录按下的x轴坐标
                        console.info("###@@ Touch Down");
                        this.downX = event.touches[0].x;
                        break;
                    case TouchType.Up: // 触摸抬起
                        console.info("###@@ Touch Up");
                        // 触摸抬起，根据x轴总偏移量，判断是否打开删除
                        let xOffset = event.touches[0].x - this.downX;
                        // 防止消费点击事件
                        if (xOffset == 0) {
                            return;
                        }
                        // 滑到x轴的位置
                        var toxOffset = 0;
                        // 开启删除的对象置为null
                        this.openedDeleteData = null;
                        // 偏移量超过删除按钮一半且左滑，设置打开
                        console.info("###Offset: " + xOffset);
                        if (Math.abs(xOffset) > vp2px(this.deleteWidth) / 2 && xOffset < 0) {
                            // 删除布局宽度
                            console.info("###Try to slide");
                            toxOffset = vp2px(this.deleteWidth);
                            console.info("###toxOffset = " + toxOffset);
                            this.openedDeleteData = item;
                            if (this.openedDeleteData.data != null)
                                console.info("###Check item: " + this.openedDeleteData.data.amount.toString());
                            else
                                console.info("###Check item: NULL");
                        }
                        // 滑动指定位置，设置动画
                        item.h_scroller.scrollTo({ xOffset: toxOffset, yOffset: 0,
                            animation: { duration: 300, curve: Curve.Linear } });
                        // 重置按下的x轴坐标
                        this.downX = 0;
                        break;
                }
            });
            if (!isInitialRender) {
                Scroll.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Index.ets(76:7)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Index.ets(77:9)");
            Row.width('100%');
            Row.height('56vp');
            Row.onClick(() => {
                this.selectListItem(item.data);
                this.dialogController.open();
            });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //图标
            Image.create(ImageList[item.data.typeText]);
            Image.debugLine("pages/Index.ets(79:11)");
            //图标
            Image.width('40vp');
            //图标
            Image.aspectRatio(CommonConstants.FULL_SIZE);
            //图标
            Image.margin({ right: '16vp' });
            if (!isInitialRender) {
                //图标
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //类别
            Text.create(item.data.typeText);
            Text.debugLine("pages/Index.ets(85:11)");
            //类别
            Text.height('22vp');
            //类别
            Text.fontSize('18vp');
            if (!isInitialRender) {
                //类别
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //类别
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //空白
            Blank.create();
            Blank.debugLine("pages/Index.ets(90:11)");
            //空白
            Blank.layoutWeight(2);
            if (!isInitialRender) {
                //空白
                Blank.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //空白
        Blank.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //备注
            Text.create(item.data.reminder.length > 4 ? item.data.reminder.substring(0, 4) + '...' : item.data.reminder);
            Text.debugLine("pages/Index.ets(94:11)");
            //备注
            Text.height('22vp');
            //备注
            Text.fontSize('16vp');
            //备注
            Text.fontColor('#767778');
            if (!isInitialRender) {
                //备注
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //备注
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //空白
            Blank.create();
            Blank.debugLine("pages/Index.ets(100:11)");
            //空白
            Blank.layoutWeight(1);
            if (!isInitialRender) {
                //空白
                Blank.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //空白
        Blank.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            //根据是否在编辑，展示删除按钮 or 总额
            if (!this.isEditing) { //总额
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create((item.data.accountType === 0 ? '-' : '+') + item.data.amount.toString());
                        Text.debugLine("pages/Index.ets(105:13)");
                        Text.fontSize('16vp');
                        Text.fontColor(item.data.accountType === 0 ? { "id": 16777224, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } : { "id": 16777223, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
                        Text.align(Alignment.End);
                        Text.flexGrow(CommonConstants.FULL_SIZE);
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Row.create();
                        Row.debugLine("pages/Index.ets(111:13)");
                        Row.align(Alignment.End);
                        Row.flexGrow(CommonConstants.FULL_SIZE);
                        Row.justifyContent(FlexAlign.End);
                        if (!isInitialRender) {
                            Row.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Toggle.create({ type: ToggleType.Checkbox });
                        Toggle.debugLine("pages/Index.ets(112:15)");
                        Toggle.onChange((isOn) => {
                            //即将删除的栏目放在deleteList中
                            if (isOn) {
                                this.deleteList.push(item.data);
                            }
                            else {
                                let index = this.deleteList.indexOf(item.data);
                                this.deleteList.splice(index, 1);
                            }
                        });
                        if (!isInitialRender) {
                            Toggle.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Toggle.pop();
                    Row.pop();
                });
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //侧滑删除栏
            Button.createWithChild();
            Button.debugLine("pages/Index.ets(135:9)");
            //侧滑删除栏
            Button.type(ButtonType.Normal);
            //侧滑删除栏
            Button.width(this.deleteWidth);
            //侧滑删除栏
            Button.height(65);
            //侧滑删除栏
            Button.backgroundColor(Color.Red);
            //侧滑删除栏
            Button.onClick(() => {
            });
            if (!isInitialRender) {
                //侧滑删除栏
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('删除');
            Text.debugLine("pages/Index.ets(136:11)");
            Text.fontSize(15);
            Text.fontColor(Color.White);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        //侧滑删除栏
        Button.pop();
        Row.pop();
        Scroll.pop();
    }
    /*页面跳转函数*/
    jumpSumPage() {
        router.pushUrl({
            url: 'pages/sumPage',
            params: {
                yPos: this.yPos
            }
        }, router.RouterMode.Single, (err) => {
            if (err) {
                console.error(`###Invoke pushUrl failed, code is ${err.code}, message is ${err.message}`);
                return;
            }
            console.info('###Invoke pushUrl succeeded.');
        });
    }
    jumpToBuyPage() {
        router.pushUrl({
            url: 'pages/toBuyPage',
            params: {
                yPos: this.yPos
            }
        }, router.RouterMode.Single, (err) => {
            if (err) {
                console.error(`###Invoke pushUrl failed, code is ${err.code}, message is ${err.message}`);
                return;
            }
            console.info('###Invoke pushUrl succeeded.');
        });
    }
    jumpMePage() {
        router.pushUrl({
            url: 'pages/mePage',
            params: {
                yPos: this.yPos
            }
        }, router.RouterMode.Single, (err) => {
            if (err) {
                console.error(`###Invoke pushUrl failed, code is ${err.code}, message is ${err.message}`);
                return;
            }
            console.info('###Invoke pushUrl succeeded.');
        });
    }
    /*跳转函数*/
    /*声明页面所需的函数*/
    aboutToAppear() {
        this.AccountTable.getRdbStore(() => {
            this.AccountTable.query(0, (result) => {
                this.accounts = result;
            }, true);
        });
    }
    selectListItem(item) {
        this.isInsert = false;
        this.index = this.accounts.indexOf(item);
        this.newAccount = {
            id: item.id,
            accountType: item.accountType,
            typeText: item.typeText,
            amount: item.amount,
            day: item.day,
            month: item.month,
            year: item.year,
            reminder: item.reminder
        };
    }
    deleteListItem() {
        for (let i = 0; i < this.deleteList.length; i++) {
            let index = this.accounts.indexOf(this.deleteList[i]);
            this.yPos[dateHelper.getWeek(this.accounts[index].day)] -= this.accounts[index].amount;
            this.accounts.splice(index, 1);
            this.AccountTable.deleteData(this.deleteList[i], () => {
            });
        }
        this.deleteList = [];
        this.isEditing = false;
        this.refresh++;
    }
    //isInsert->插入数据; !isInsert->修改数据
    accept(isInsert, newAccount) {
        //计算目标日期到今天日期的时间
        let week = dateHelper.getWeek(newAccount.day);
        console.info('###星期是：' + week);
        //新项目
        if (isInsert) {
            Logger.info(`${CommonConstants.INDEX_TAG}`, `The account inserted is:  ${JSON.stringify(newAccount)}`);
            this.AccountTable.insertData(newAccount, (id) => {
                newAccount.id = id;
                this.accounts.push(newAccount);
            });
            this.yPos[week] += newAccount.amount;
            //更新总额
            if (week == 0)
                this.daySum += newAccount.amount;
            this.monSum += newAccount.amount;
            console.info("###更新yPos");
            console.info("###yPos: " + this.yPos[0] + " || " + this.yPos[1]);
        }
        else { //修改旧项目
            this.yPos[week] -= this.newAccount.amount;
            this.yPos[week] += newAccount.amount;
            this.AccountTable.updateData(newAccount, () => {
            });
            let list = this.accounts;
            this.accounts = [];
            list[this.index] = newAccount;
            this.accounts = list;
            this.index = -1;
        }
        //刷新曲线
        this.refresh++;
        //调起FormEntryAbility
        postCardAction(this, {
            'action': 'message',
            'params': {
                'info': this.yPos
            }
        });
    }
    common_records(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Index.ets(341:5)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Index.ets(342:7)");
            Row.width('100%');
            Row.padding({ left: '12vp', right: '12vp' });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild();
            Button.debugLine("pages/Index.ets(345:7)");
            Button.type((ButtonType.Normal));
            Button.height(65);
            Button.backgroundColor(Color.Red);
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('删除');
            Text.debugLine("pages/Index.ets(346:9)");
            Text.fontSize(15);
            Text.fontColor(Color.White);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Button.pop();
        Row.pop();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create();
            Stack.debugLine("pages/Index.ets(357:5)");
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Index.ets(358:7)");
            Column.width('100%');
            Column.height('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            List.create();
            List.debugLine("pages/Index.ets(359:9)");
            if (!isInitialRender) {
                List.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            const isLazyCreate = true;
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                ListItem.create(deepRenderFunction, isLazyCreate);
                ListItem.debugLine("pages/Index.ets(360:11)");
                if (!isInitialRender) {
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const observedShallowRender = () => {
                this.observeComponentCreation(itemCreation);
                ListItem.pop();
            };
            const observedDeepRender = () => {
                this.observeComponentCreation(itemCreation);
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    //标题 & 编辑按钮
                    Row.create();
                    Row.debugLine("pages/Index.ets(362:13)");
                    //标题 & 编辑按钮
                    Row.sharedTransition('title', { duration: 500, curve: Curve.Linear });
                    //标题 & 编辑按钮
                    Row.backgroundColor({ "id": 16777219, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
                    //标题 & 编辑按钮
                    Row.width('100%');
                    //标题 & 编辑按钮
                    Row.height('20%');
                    //标题 & 编辑按钮
                    Row.justifyContent(FlexAlign.SpaceBetween);
                    if (!isInitialRender) {
                        //标题 & 编辑按钮
                        Row.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create(this.title);
                    Text.debugLine("pages/Index.ets(363:15)");
                    Text.fontColor(Color.White);
                    Text.height(30);
                    Text.fontSize(30);
                    Text.margin({ left: 24, bottom: '50vp' });
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Image.create({ "id": 0, "type": 30000, params: ['mainPage_editAll.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" });
                    Image.debugLine("pages/Index.ets(368:15)");
                    Image.autoResize(true);
                    Image.size({ width: 30, height: 30 });
                    Image.fillColor(Color.White);
                    Image.margin({ right: 24, bottom: '50vp' });
                    Image.onClick(() => {
                        this.isEditing = !this.isEditing;
                    });
                    Image.sharedTransition('editIcon', { duration: 500, curve: Curve.Linear, type: SharedTransitionEffectType.Static });
                    if (!isInitialRender) {
                        Image.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                //标题 & 编辑按钮
                Row.pop();
                ListItem.pop();
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.updateFuncByElmtId.set(elmtId, itemCreation);
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    //标题 & 编辑按钮
                    Row.create();
                    Row.debugLine("pages/Index.ets(362:13)");
                    //标题 & 编辑按钮
                    Row.sharedTransition('title', { duration: 500, curve: Curve.Linear });
                    //标题 & 编辑按钮
                    Row.backgroundColor({ "id": 16777219, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
                    //标题 & 编辑按钮
                    Row.width('100%');
                    //标题 & 编辑按钮
                    Row.height('20%');
                    //标题 & 编辑按钮
                    Row.justifyContent(FlexAlign.SpaceBetween);
                    if (!isInitialRender) {
                        //标题 & 编辑按钮
                        Row.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create(this.title);
                    Text.debugLine("pages/Index.ets(363:15)");
                    Text.fontColor(Color.White);
                    Text.height(30);
                    Text.fontSize(30);
                    Text.margin({ left: 24, bottom: '50vp' });
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Image.create({ "id": 0, "type": 30000, params: ['mainPage_editAll.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" });
                    Image.debugLine("pages/Index.ets(368:15)");
                    Image.autoResize(true);
                    Image.size({ width: 30, height: 30 });
                    Image.fillColor(Color.White);
                    Image.margin({ right: 24, bottom: '50vp' });
                    Image.onClick(() => {
                        this.isEditing = !this.isEditing;
                    });
                    Image.sharedTransition('editIcon', { duration: 500, curve: Curve.Linear, type: SharedTransitionEffectType.Static });
                    if (!isInitialRender) {
                        Image.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                //标题 & 编辑按钮
                Row.pop();
                ListItem.pop();
            };
            if (isLazyCreate) {
                observedShallowRender();
            }
            else {
                observedDeepRender();
            }
        }
        {
            const isLazyCreate = true;
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                ListItem.create(deepRenderFunction, isLazyCreate);
                /*图标部分
                ListItem(){
                  Flex({ direction: FlexDirection.Column, alignItems: ItemAlign.Center, justifyContent: FlexAlign.Center }) {
                    Canvas(this.refresh!=0?this.context:null)
                      .width('100%')
                      .height('100%')
                      .backgroundColor('')
                      .onReady(() =>{
                        this.offContext.lineWidth = 3;
                        this.offContext.beginPath();
                        this.offContext.lineCap = 'round';
                        this.offContext.lineJoin = 'round';
                        this.offContext.strokeStyle = '#ECFFE9';
      
                        this.offContext.moveTo(this.xPos[0], this.yPos[0]);
                        let tot = 0;
                        for(let i = 0; i<7; i++){
                          tot += this.yPos[i];
                        }
      
                        //画首个点
                        let path: Path2D = new Path2D();
                        path.arc(this.xPos[0],60-this.yPos[0]/tot*60,5,0,360);
                        this.offContext.fillStyle = '#ECFFE9'
                        this.offContext.fill(path);
                        //画其余点
                        this.offContext.moveTo(this.xPos[0], 60-this.yPos[0]/tot*60);
                        for(let i = 1; i<7; i++){
                          let path: Path2D = new Path2D();
                          path.arc(this.xPos[i],60-this.yPos[i]/tot*60,5,0,360);
                          this.offContext.fill(path);
                          this.offContext.lineTo(this.xPos[i], 60-this.yPos[i]/tot*60);
                        }
      
                        this.offContext.stroke();
                        var image = this.offContext.transferToImageBitmap();
                        this.context.transferFromImageBitmap(image);
                      })
                  }
                  .sharedTransition('curve', { duration: 500, curve: Curve.Linear,type:SharedTransitionEffectType.Static})
                }
                .width('100%')
                .height('8%')
                .position({x:this.refresh-this.refresh,y:'10%'})
                图表部分*/
                /*总消费*/
                ListItem.width('100%');
                /*图标部分
                ListItem(){
                  Flex({ direction: FlexDirection.Column, alignItems: ItemAlign.Center, justifyContent: FlexAlign.Center }) {
                    Canvas(this.refresh!=0?this.context:null)
                      .width('100%')
                      .height('100%')
                      .backgroundColor('')
                      .onReady(() =>{
                        this.offContext.lineWidth = 3;
                        this.offContext.beginPath();
                        this.offContext.lineCap = 'round';
                        this.offContext.lineJoin = 'round';
                        this.offContext.strokeStyle = '#ECFFE9';
      
                        this.offContext.moveTo(this.xPos[0], this.yPos[0]);
                        let tot = 0;
                        for(let i = 0; i<7; i++){
                          tot += this.yPos[i];
                        }
      
                        //画首个点
                        let path: Path2D = new Path2D();
                        path.arc(this.xPos[0],60-this.yPos[0]/tot*60,5,0,360);
                        this.offContext.fillStyle = '#ECFFE9'
                        this.offContext.fill(path);
                        //画其余点
                        this.offContext.moveTo(this.xPos[0], 60-this.yPos[0]/tot*60);
                        for(let i = 1; i<7; i++){
                          let path: Path2D = new Path2D();
                          path.arc(this.xPos[i],60-this.yPos[i]/tot*60,5,0,360);
                          this.offContext.fill(path);
                          this.offContext.lineTo(this.xPos[i], 60-this.yPos[i]/tot*60);
                        }
      
                        this.offContext.stroke();
                        var image = this.offContext.transferToImageBitmap();
                        this.context.transferFromImageBitmap(image);
                      })
                  }
                  .sharedTransition('curve', { duration: 500, curve: Curve.Linear,type:SharedTransitionEffectType.Static})
                }
                .width('100%')
                .height('8%')
                .position({x:this.refresh-this.refresh,y:'10%'})
                图表部分*/
                /*总消费*/
                ListItem.height('8%');
                /*图标部分
                ListItem(){
                  Flex({ direction: FlexDirection.Column, alignItems: ItemAlign.Center, justifyContent: FlexAlign.Center }) {
                    Canvas(this.refresh!=0?this.context:null)
                      .width('100%')
                      .height('100%')
                      .backgroundColor('')
                      .onReady(() =>{
                        this.offContext.lineWidth = 3;
                        this.offContext.beginPath();
                        this.offContext.lineCap = 'round';
                        this.offContext.lineJoin = 'round';
                        this.offContext.strokeStyle = '#ECFFE9';
      
                        this.offContext.moveTo(this.xPos[0], this.yPos[0]);
                        let tot = 0;
                        for(let i = 0; i<7; i++){
                          tot += this.yPos[i];
                        }
      
                        //画首个点
                        let path: Path2D = new Path2D();
                        path.arc(this.xPos[0],60-this.yPos[0]/tot*60,5,0,360);
                        this.offContext.fillStyle = '#ECFFE9'
                        this.offContext.fill(path);
                        //画其余点
                        this.offContext.moveTo(this.xPos[0], 60-this.yPos[0]/tot*60);
                        for(let i = 1; i<7; i++){
                          let path: Path2D = new Path2D();
                          path.arc(this.xPos[i],60-this.yPos[i]/tot*60,5,0,360);
                          this.offContext.fill(path);
                          this.offContext.lineTo(this.xPos[i], 60-this.yPos[i]/tot*60);
                        }
      
                        this.offContext.stroke();
                        var image = this.offContext.transferToImageBitmap();
                        this.context.transferFromImageBitmap(image);
                      })
                  }
                  .sharedTransition('curve', { duration: 500, curve: Curve.Linear,type:SharedTransitionEffectType.Static})
                }
                .width('100%')
                .height('8%')
                .position({x:this.refresh-this.refresh,y:'10%'})
                图表部分*/
                /*总消费*/
                ListItem.position({ x: this.refresh - this.refresh, y: '10%' });
                ListItem.debugLine("pages/Index.ets(432:11)");
                if (!isInitialRender) {
                    /*图标部分
                    ListItem(){
                      Flex({ direction: FlexDirection.Column, alignItems: ItemAlign.Center, justifyContent: FlexAlign.Center }) {
                        Canvas(this.refresh!=0?this.context:null)
                          .width('100%')
                          .height('100%')
                          .backgroundColor('')
                          .onReady(() =>{
                            this.offContext.lineWidth = 3;
                            this.offContext.beginPath();
                            this.offContext.lineCap = 'round';
                            this.offContext.lineJoin = 'round';
                            this.offContext.strokeStyle = '#ECFFE9';
          
                            this.offContext.moveTo(this.xPos[0], this.yPos[0]);
                            let tot = 0;
                            for(let i = 0; i<7; i++){
                              tot += this.yPos[i];
                            }
          
                            //画首个点
                            let path: Path2D = new Path2D();
                            path.arc(this.xPos[0],60-this.yPos[0]/tot*60,5,0,360);
                            this.offContext.fillStyle = '#ECFFE9'
                            this.offContext.fill(path);
                            //画其余点
                            this.offContext.moveTo(this.xPos[0], 60-this.yPos[0]/tot*60);
                            for(let i = 1; i<7; i++){
                              let path: Path2D = new Path2D();
                              path.arc(this.xPos[i],60-this.yPos[i]/tot*60,5,0,360);
                              this.offContext.fill(path);
                              this.offContext.lineTo(this.xPos[i], 60-this.yPos[i]/tot*60);
                            }
          
                            this.offContext.stroke();
                            var image = this.offContext.transferToImageBitmap();
                            this.context.transferFromImageBitmap(image);
                          })
                      }
                      .sharedTransition('curve', { duration: 500, curve: Curve.Linear,type:SharedTransitionEffectType.Static})
                    }
                    .width('100%')
                    .height('8%')
                    .position({x:this.refresh-this.refresh,y:'10%'})
                    图表部分*/
                    /*总消费*/
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const observedShallowRender = () => {
                this.observeComponentCreation(itemCreation);
                /*图标部分
                ListItem(){
                  Flex({ direction: FlexDirection.Column, alignItems: ItemAlign.Center, justifyContent: FlexAlign.Center }) {
                    Canvas(this.refresh!=0?this.context:null)
                      .width('100%')
                      .height('100%')
                      .backgroundColor('')
                      .onReady(() =>{
                        this.offContext.lineWidth = 3;
                        this.offContext.beginPath();
                        this.offContext.lineCap = 'round';
                        this.offContext.lineJoin = 'round';
                        this.offContext.strokeStyle = '#ECFFE9';
      
                        this.offContext.moveTo(this.xPos[0], this.yPos[0]);
                        let tot = 0;
                        for(let i = 0; i<7; i++){
                          tot += this.yPos[i];
                        }
      
                        //画首个点
                        let path: Path2D = new Path2D();
                        path.arc(this.xPos[0],60-this.yPos[0]/tot*60,5,0,360);
                        this.offContext.fillStyle = '#ECFFE9'
                        this.offContext.fill(path);
                        //画其余点
                        this.offContext.moveTo(this.xPos[0], 60-this.yPos[0]/tot*60);
                        for(let i = 1; i<7; i++){
                          let path: Path2D = new Path2D();
                          path.arc(this.xPos[i],60-this.yPos[i]/tot*60,5,0,360);
                          this.offContext.fill(path);
                          this.offContext.lineTo(this.xPos[i], 60-this.yPos[i]/tot*60);
                        }
      
                        this.offContext.stroke();
                        var image = this.offContext.transferToImageBitmap();
                        this.context.transferFromImageBitmap(image);
                      })
                  }
                  .sharedTransition('curve', { duration: 500, curve: Curve.Linear,type:SharedTransitionEffectType.Static})
                }
                .width('100%')
                .height('8%')
                .position({x:this.refresh-this.refresh,y:'10%'})
                图表部分*/
                /*总消费*/
                ListItem.pop();
            };
            const observedDeepRender = () => {
                this.observeComponentCreation(itemCreation);
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Column.create();
                    Column.debugLine("pages/Index.ets(433:13)");
                    if (!isInitialRender) {
                        Column.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create('今天消费: ' + this.daySum + '元');
                    Text.debugLine("pages/Index.ets(434:15)");
                    Text.fontColor(Color.White);
                    Text.fontSize('24vp');
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create('本月消费: ' + this.monSum + '元');
                    Text.debugLine("pages/Index.ets(437:15)");
                    Text.fontColor(Color.White);
                    Text.fontSize('24vp');
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                Column.pop();
                /*图标部分
                ListItem(){
                  Flex({ direction: FlexDirection.Column, alignItems: ItemAlign.Center, justifyContent: FlexAlign.Center }) {
                    Canvas(this.refresh!=0?this.context:null)
                      .width('100%')
                      .height('100%')
                      .backgroundColor('')
                      .onReady(() =>{
                        this.offContext.lineWidth = 3;
                        this.offContext.beginPath();
                        this.offContext.lineCap = 'round';
                        this.offContext.lineJoin = 'round';
                        this.offContext.strokeStyle = '#ECFFE9';
      
                        this.offContext.moveTo(this.xPos[0], this.yPos[0]);
                        let tot = 0;
                        for(let i = 0; i<7; i++){
                          tot += this.yPos[i];
                        }
      
                        //画首个点
                        let path: Path2D = new Path2D();
                        path.arc(this.xPos[0],60-this.yPos[0]/tot*60,5,0,360);
                        this.offContext.fillStyle = '#ECFFE9'
                        this.offContext.fill(path);
                        //画其余点
                        this.offContext.moveTo(this.xPos[0], 60-this.yPos[0]/tot*60);
                        for(let i = 1; i<7; i++){
                          let path: Path2D = new Path2D();
                          path.arc(this.xPos[i],60-this.yPos[i]/tot*60,5,0,360);
                          this.offContext.fill(path);
                          this.offContext.lineTo(this.xPos[i], 60-this.yPos[i]/tot*60);
                        }
      
                        this.offContext.stroke();
                        var image = this.offContext.transferToImageBitmap();
                        this.context.transferFromImageBitmap(image);
                      })
                  }
                  .sharedTransition('curve', { duration: 500, curve: Curve.Linear,type:SharedTransitionEffectType.Static})
                }
                .width('100%')
                .height('8%')
                .position({x:this.refresh-this.refresh,y:'10%'})
                图表部分*/
                /*总消费*/
                ListItem.pop();
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.updateFuncByElmtId.set(elmtId, itemCreation);
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Column.create();
                    Column.debugLine("pages/Index.ets(433:13)");
                    if (!isInitialRender) {
                        Column.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create('今天消费: ' + this.daySum + '元');
                    Text.debugLine("pages/Index.ets(434:15)");
                    Text.fontColor(Color.White);
                    Text.fontSize('24vp');
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create('本月消费: ' + this.monSum + '元');
                    Text.debugLine("pages/Index.ets(437:15)");
                    Text.fontColor(Color.White);
                    Text.fontSize('24vp');
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                Column.pop();
                /*图标部分
                ListItem(){
                  Flex({ direction: FlexDirection.Column, alignItems: ItemAlign.Center, justifyContent: FlexAlign.Center }) {
                    Canvas(this.refresh!=0?this.context:null)
                      .width('100%')
                      .height('100%')
                      .backgroundColor('')
                      .onReady(() =>{
                        this.offContext.lineWidth = 3;
                        this.offContext.beginPath();
                        this.offContext.lineCap = 'round';
                        this.offContext.lineJoin = 'round';
                        this.offContext.strokeStyle = '#ECFFE9';
      
                        this.offContext.moveTo(this.xPos[0], this.yPos[0]);
                        let tot = 0;
                        for(let i = 0; i<7; i++){
                          tot += this.yPos[i];
                        }
      
                        //画首个点
                        let path: Path2D = new Path2D();
                        path.arc(this.xPos[0],60-this.yPos[0]/tot*60,5,0,360);
                        this.offContext.fillStyle = '#ECFFE9'
                        this.offContext.fill(path);
                        //画其余点
                        this.offContext.moveTo(this.xPos[0], 60-this.yPos[0]/tot*60);
                        for(let i = 1; i<7; i++){
                          let path: Path2D = new Path2D();
                          path.arc(this.xPos[i],60-this.yPos[i]/tot*60,5,0,360);
                          this.offContext.fill(path);
                          this.offContext.lineTo(this.xPos[i], 60-this.yPos[i]/tot*60);
                        }
      
                        this.offContext.stroke();
                        var image = this.offContext.transferToImageBitmap();
                        this.context.transferFromImageBitmap(image);
                      })
                  }
                  .sharedTransition('curve', { duration: 500, curve: Curve.Linear,type:SharedTransitionEffectType.Static})
                }
                .width('100%')
                .height('8%')
                .position({x:this.refresh-this.refresh,y:'10%'})
                图表部分*/
                /*总消费*/
                ListItem.pop();
            };
            if (isLazyCreate) {
                observedShallowRender();
            }
            else {
                observedDeepRender();
            }
        }
        {
            const isLazyCreate = true;
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                ListItem.create(deepRenderFunction, isLazyCreate);
                //搜索栏
                ListItem.position({ x: 0, y: '20%' });
                //搜索栏
                ListItem.sharedTransition('searchCol', { duration: 500, curve: Curve.Linear, type: SharedTransitionEffectType.Static });
                ListItem.debugLine("pages/Index.ets(447:11)");
                if (!isInitialRender) {
                    //搜索栏
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const observedShallowRender = () => {
                this.observeComponentCreation(itemCreation);
                //搜索栏
                ListItem.pop();
            };
            const observedDeepRender = () => {
                this.observeComponentCreation(itemCreation);
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Row.create();
                    Row.debugLine("pages/Index.ets(448:13)");
                    Row.width('100%');
                    Row.padding({ left: '12vp', right: '12vp' });
                    Row.margin({ bottom: '8vp' });
                    if (!isInitialRender) {
                        Row.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Search.create({
                        value: this.searchText,
                        placeholder: CommonConstants.SEARCH_TEXT,
                        controller: this.searchController
                    });
                    Search.debugLine("pages/Index.ets(449:15)");
                    Search.width(CommonConstants.FULL_WIDTH);
                    Search.borderRadius('20vp');
                    Search.borderWidth('1.5vp');
                    Search.borderColor('#33182431');
                    Search.placeholderFont({ size: '16vp' });
                    Search.textFont({ size: '16vp' });
                    Search.backgroundColor(Color.White);
                    Search.onChange((inputText) => {
                        this.searchText = inputText;
                    });
                    Search.onSubmit((inputText) => {
                        if (inputText === '') {
                            this.AccountTable.query(0, (result) => {
                                this.accounts = result;
                            }, true);
                        }
                        else {
                            this.AccountTable.query(Number(inputText), (result) => {
                                this.accounts = result;
                            }, false);
                        }
                    });
                    if (!isInitialRender) {
                        Search.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Search.pop();
                Row.pop();
                //搜索栏
                ListItem.pop();
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.updateFuncByElmtId.set(elmtId, itemCreation);
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Row.create();
                    Row.debugLine("pages/Index.ets(448:13)");
                    Row.width('100%');
                    Row.padding({ left: '12vp', right: '12vp' });
                    Row.margin({ bottom: '8vp' });
                    if (!isInitialRender) {
                        Row.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Search.create({
                        value: this.searchText,
                        placeholder: CommonConstants.SEARCH_TEXT,
                        controller: this.searchController
                    });
                    Search.debugLine("pages/Index.ets(449:15)");
                    Search.width(CommonConstants.FULL_WIDTH);
                    Search.borderRadius('20vp');
                    Search.borderWidth('1.5vp');
                    Search.borderColor('#33182431');
                    Search.placeholderFont({ size: '16vp' });
                    Search.textFont({ size: '16vp' });
                    Search.backgroundColor(Color.White);
                    Search.onChange((inputText) => {
                        this.searchText = inputText;
                    });
                    Search.onSubmit((inputText) => {
                        if (inputText === '') {
                            this.AccountTable.query(0, (result) => {
                                this.accounts = result;
                            }, true);
                        }
                        else {
                            this.AccountTable.query(Number(inputText), (result) => {
                                this.accounts = result;
                            }, false);
                        }
                    });
                    if (!isInitialRender) {
                        Search.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Search.pop();
                Row.pop();
                //搜索栏
                ListItem.pop();
            };
            if (isLazyCreate) {
                observedShallowRender();
            }
            else {
                observedDeepRender();
            }
        }
        {
            const isLazyCreate = true;
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                ListItem.create(deepRenderFunction, isLazyCreate);
                //展示栏
                ListItem.position({ x: 0, y: '28%' });
                ListItem.debugLine("pages/Index.ets(484:11)");
                if (!isInitialRender) {
                    //展示栏
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const observedShallowRender = () => {
                this.observeComponentCreation(itemCreation);
                //展示栏
                ListItem.pop();
            };
            const observedDeepRender = () => {
                this.observeComponentCreation(itemCreation);
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Column.create();
                    Column.debugLine("pages/Index.ets(485:15)");
                    Column.width('100%');
                    Column.borderRadius('24vp');
                    Column.backgroundColor(Color.White);
                    if (!isInitialRender) {
                        Column.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    ForEach.create();
                    const forEachItemGenFunction = _item => {
                        const item = _item;
                        //每一栏记录：
                        this.CustomItem.bind(this)(new showingColumn(item, new Scroller()));
                    };
                    this.forEachUpdateFunction(elmtId, this.accounts, forEachItemGenFunction);
                    if (!isInitialRender) {
                        ForEach.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                ForEach.pop();
                Column.pop();
                //展示栏
                ListItem.pop();
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.updateFuncByElmtId.set(elmtId, itemCreation);
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Column.create();
                    Column.debugLine("pages/Index.ets(485:15)");
                    Column.width('100%');
                    Column.borderRadius('24vp');
                    Column.backgroundColor(Color.White);
                    if (!isInitialRender) {
                        Column.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    ForEach.create();
                    const forEachItemGenFunction = _item => {
                        const item = _item;
                        //每一栏记录：
                        this.CustomItem.bind(this)(new showingColumn(item, new Scroller()));
                    };
                    this.forEachUpdateFunction(elmtId, this.accounts, forEachItemGenFunction);
                    if (!isInitialRender) {
                        ForEach.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                ForEach.pop();
                Column.pop();
                //展示栏
                ListItem.pop();
            };
            if (isLazyCreate) {
                observedShallowRender();
            }
            else {
                observedDeepRender();
            }
        }
        List.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //在这里补充界面下方的UI
            Row.create();
            Row.debugLine("pages/Index.ets(501:9)");
            //在这里补充界面下方的UI
            Row.sharedTransition('sharedImage1', { duration: 500, curve: Curve.Linear });
            //在这里补充界面下方的UI
            Row.position({ x: '50%', y: '100%' });
            if (!isInitialRender) {
                //在这里补充界面下方的UI
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            //“添加”按钮：增加记账记录
            if (!this.isEditing) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Button.createWithChild({ type: ButtonType.Capsule, stateEffect: true });
                        Button.debugLine("pages/Index.ets(504:13)");
                        Button.width('70vp');
                        Button.height('70vp');
                        Button.markAnchor({ x: '35vp', y: 0 });
                        Button.position({ x: '50%', y: '89%' });
                        Button.backgroundColor(Color.White);
                        Button.onClick(() => {
                            this.isInsert = true;
                            this.newAccount = {
                                id: 0,
                                accountType: 0,
                                typeText: '',
                                amount: 0,
                                day: '',
                                month: '',
                                year: '',
                                reminder: ''
                            };
                            /*获取当前时间*/
                            systemDateTime.getDate().then((date) => {
                                console.info('###' + JSON.stringify(date.getDate().toString()));
                                this.newAccount.month = date.getMonth().toString();
                                this.newAccount.year = date.getFullYear().toString();
                                this.newAccount.day = date.getFullYear().toString() + '年'
                                    + date.getMonth().toString() + '月'
                                    + date.getDate().toString() + '日';
                            });
                            this.dialogController.open();
                        });
                        if (!isInitialRender) {
                            Button.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Image.create({ "id": 0, "type": 30000, params: ['mainPage_addIcon.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" });
                        Image.debugLine("pages/Index.ets(505:15)");
                        Image.width('65vp');
                        Image.height('65vp');
                        Image.fillColor({ "id": 16777219, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
                        if (!isInitialRender) {
                            Image.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Button.pop();
                });
            }
            //批量删除按钮
            else {
                If.branchId(1);
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            //批量删除按钮
            if (this.isEditing) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Button.createWithChild({ type: ButtonType.Circle, stateEffect: true });
                        Button.debugLine("pages/Index.ets(543:13)");
                        Button.width('65vp');
                        Button.height('65vp');
                        Button.markAnchor({ x: '34vp', y: 0 });
                        Button.backgroundColor('#C3C3C3');
                        Button.position({ x: '50%', y: '89%' });
                        Button.onClick(() => {
                            this.deleteListItem();
                        });
                        if (!isInitialRender) {
                            Button.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Image.create({ "id": 0, "type": 30000, params: ['mainPage_deleteIcon.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" });
                        Image.debugLine("pages/Index.ets(544:15)");
                        Image.fillColor('#F1F3F5');
                        Image.width('55vp');
                        Image.width('55vp');
                        if (!isInitialRender) {
                            Image.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Button.pop();
                });
            }
            //左1：明细
            else {
                If.branchId(1);
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //左1：明细
            Column.create();
            Column.debugLine("pages/Index.ets(560:11)");
            //左1：明细
            Column.position({ x: '4%', y: '92%' });
            if (!isInitialRender) {
                //左1：明细
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild({ type: ButtonType.Circle, stateEffect: true });
            Button.debugLine("pages/Index.ets(561:13)");
            Button.width('40vp');
            Button.height('40vp');
            Button.backgroundColor('#F1F3F5');
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ['page_detail.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Image.debugLine("pages/Index.ets(562:15)");
            Image.fillColor({ "id": 16777219, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Image.width('35vp');
            Image.height('35vp');
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('明细');
            Text.debugLine("pages/Index.ets(571:13)");
            Text.fontColor(Color.Black);
            Text.fontSize('15vp');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        //左1：明细
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //左2：统计
            Column.create();
            Column.debugLine("pages/Index.ets(578:11)");
            //左2：统计
            Column.position({ x: '25%', y: '92%' });
            if (!isInitialRender) {
                //左2：统计
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild({ type: ButtonType.Circle, stateEffect: true });
            Button.debugLine("pages/Index.ets(579:13)");
            Button.width('40vp');
            Button.height('40vp');
            Button.backgroundColor('#F1F3F5');
            Button.onClick(() => {
                console.info('###Jump to EntryAbility sumPage');
                this.jumpSumPage();
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ['page_sum.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Image.debugLine("pages/Index.ets(580:15)");
            Image.fillColor(Color.Gray);
            Image.width('35vp');
            Image.height('35vp');
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('统计');
            Text.debugLine("pages/Index.ets(593:13)");
            Text.fontColor(Color.Black);
            Text.fontSize('15vp');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        //左2：统计
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //右1：ToDo List
            Column.create();
            Column.debugLine("pages/Index.ets(600:11)");
            //右1：ToDo List
            Column.position({ x: '65%', y: '91.5%' });
            if (!isInitialRender) {
                //右1：ToDo List
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild({ type: ButtonType.Circle, stateEffect: true });
            Button.debugLine("pages/Index.ets(601:13)");
            Button.width('40vp');
            Button.height('40vp');
            Button.backgroundColor('#F1F3F5');
            Button.onClick(() => {
                this.jumpToBuyPage();
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ['page_tobuy.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Image.debugLine("pages/Index.ets(602:15)");
            Image.fillColor(Color.Gray);
            Image.width('40vp');
            Image.height('40vp');
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('清单');
            Text.debugLine("pages/Index.ets(614:13)");
            Text.fontColor(Color.Black);
            Text.fontSize('15vp');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        //右1：ToDo List
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //左2：我的
            Column.create();
            Column.debugLine("pages/Index.ets(621:11)");
            //左2：我的
            Column.position({ x: '85%', y: '91.5%' });
            if (!isInitialRender) {
                //左2：我的
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild({ type: ButtonType.Circle, stateEffect: true });
            Button.debugLine("pages/Index.ets(622:13)");
            Button.width('40vp');
            Button.height('40vp');
            Button.backgroundColor('#F1F3F5');
            Button.onClick(() => {
                console.info('###Jump to EntryAbility sumPage');
                this.jumpMePage();
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ['page_me.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Image.debugLine("pages/Index.ets(623:15)");
            Image.fillColor(Color.Gray);
            Image.width('35vp');
            Image.height('35vp');
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('我的');
            Text.debugLine("pages/Index.ets(636:13)");
            Text.fontColor(Color.Black);
            Text.fontSize('15vp');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        //左2：我的
        Column.pop();
        //在这里补充界面下方的UI
        Row.pop();
        Column.pop();
        Stack.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new Index(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=Index.js.map