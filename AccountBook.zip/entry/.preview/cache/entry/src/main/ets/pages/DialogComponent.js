/*
 * Copyright (c) 2023 Huawei Device Co., Ltd.
 * Licensed under the Apache License,Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import prompt from '@ohos:promptAction';
import CommonConstants from '@bundle:com.example.accountbook/entry/ets/database/CommonConstants';
import { PayList, EarnList } from '@bundle:com.example.accountbook/entry/ets/bean/AccountList';
export class DialogComponent extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.controller = undefined;
        this.__isInsert = new SynchedPropertySimpleTwoWayPU(params.isInsert, this, "isInsert");
        this.__newAccount = new SynchedPropertyObjectTwoWayPU(params.newAccount, this, "newAccount");
        this.confirm = undefined;
        this.scroller = new Scroller();
        this.inputAmount = '';
        this.inputRemind = '';
        this.currDate = '';
        this.__payList = new ObservedPropertyObjectPU(PayList, this, "payList");
        this.__earnList = new ObservedPropertyObjectPU(EarnList, this, "earnList");
        this.__bgColor = new ObservedPropertySimplePU('', this, "bgColor");
        this.__curIndex = new ObservedPropertySimplePU(0, this, "curIndex");
        this.__curType = new ObservedPropertySimplePU('', this, "curType");
        this.__curDay = new ObservedPropertySimplePU('', this, "curDay");
        this.__curYear = new ObservedPropertySimplePU('', this, "curYear");
        this.__curMonth = new ObservedPropertySimplePU('', this, "curMonth");
        this.__curReminder = new ObservedPropertySimplePU('', this, "curReminder");
        this.selected_date = undefined;
        this.__drag = new ObservedPropertySimplePU(false, this, "drag");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
        if (params.confirm !== undefined) {
            this.confirm = params.confirm;
        }
        if (params.scroller !== undefined) {
            this.scroller = params.scroller;
        }
        if (params.inputAmount !== undefined) {
            this.inputAmount = params.inputAmount;
        }
        if (params.inputRemind !== undefined) {
            this.inputRemind = params.inputRemind;
        }
        if (params.currDate !== undefined) {
            this.currDate = params.currDate;
        }
        if (params.payList !== undefined) {
            this.payList = params.payList;
        }
        if (params.earnList !== undefined) {
            this.earnList = params.earnList;
        }
        if (params.bgColor !== undefined) {
            this.bgColor = params.bgColor;
        }
        if (params.curIndex !== undefined) {
            this.curIndex = params.curIndex;
        }
        if (params.curType !== undefined) {
            this.curType = params.curType;
        }
        if (params.curDay !== undefined) {
            this.curDay = params.curDay;
        }
        if (params.curYear !== undefined) {
            this.curYear = params.curYear;
        }
        if (params.curMonth !== undefined) {
            this.curMonth = params.curMonth;
        }
        if (params.curReminder !== undefined) {
            this.curReminder = params.curReminder;
        }
        if (params.selected_date !== undefined) {
            this.selected_date = params.selected_date;
        }
        if (params.drag !== undefined) {
            this.drag = params.drag;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__isInsert.purgeDependencyOnElmtId(rmElmtId);
        this.__newAccount.purgeDependencyOnElmtId(rmElmtId);
        this.__payList.purgeDependencyOnElmtId(rmElmtId);
        this.__earnList.purgeDependencyOnElmtId(rmElmtId);
        this.__bgColor.purgeDependencyOnElmtId(rmElmtId);
        this.__curIndex.purgeDependencyOnElmtId(rmElmtId);
        this.__curType.purgeDependencyOnElmtId(rmElmtId);
        this.__curDay.purgeDependencyOnElmtId(rmElmtId);
        this.__curYear.purgeDependencyOnElmtId(rmElmtId);
        this.__curMonth.purgeDependencyOnElmtId(rmElmtId);
        this.__curReminder.purgeDependencyOnElmtId(rmElmtId);
        this.__drag.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__isInsert.aboutToBeDeleted();
        this.__newAccount.aboutToBeDeleted();
        this.__payList.aboutToBeDeleted();
        this.__earnList.aboutToBeDeleted();
        this.__bgColor.aboutToBeDeleted();
        this.__curIndex.aboutToBeDeleted();
        this.__curType.aboutToBeDeleted();
        this.__curDay.aboutToBeDeleted();
        this.__curYear.aboutToBeDeleted();
        this.__curMonth.aboutToBeDeleted();
        this.__curReminder.aboutToBeDeleted();
        this.__drag.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    setController(ctr) {
        this.controller = ctr;
    }
    get isInsert() {
        return this.__isInsert.get();
    }
    set isInsert(newValue) {
        this.__isInsert.set(newValue);
    }
    get newAccount() {
        return this.__newAccount.get();
    }
    set newAccount(newValue) {
        this.__newAccount.set(newValue);
    }
    get payList() {
        return this.__payList.get();
    }
    set payList(newValue) {
        this.__payList.set(newValue);
    }
    get earnList() {
        return this.__earnList.get();
    }
    set earnList(newValue) {
        this.__earnList.set(newValue);
    }
    get bgColor() {
        return this.__bgColor.get();
    }
    set bgColor(newValue) {
        this.__bgColor.set(newValue);
    }
    get curIndex() {
        return this.__curIndex.get();
    }
    set curIndex(newValue) {
        this.__curIndex.set(newValue);
    }
    get curType() {
        return this.__curType.get();
    }
    set curType(newValue) {
        this.__curType.set(newValue);
    }
    get curDay() {
        return this.__curDay.get();
    }
    set curDay(newValue) {
        this.__curDay.set(newValue);
    }
    get curYear() {
        return this.__curYear.get();
    }
    set curYear(newValue) {
        this.__curYear.set(newValue);
    }
    get curMonth() {
        return this.__curMonth.get();
    }
    set curMonth(newValue) {
        this.__curMonth.set(newValue);
    }
    get curReminder() {
        return this.__curReminder.get();
    }
    set curReminder(newValue) {
        this.__curReminder.set(newValue);
    }
    get drag() {
        return this.__drag.get();
    }
    set drag(newValue) {
        this.__drag.set(newValue);
    }
    TabBuilder(index, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/DialogComponent.ets(50:5)");
            Column.width('48vp');
            Column.padding({ top: '17vp', bottom: '8vp' });
            Column.margin({ bottom: '8vp' });
            Column.border(this.curIndex === index ? {
                width: { bottom: '2vp' },
                color: '#018F90'
            } : { color: Color.White });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(index === 0 ? { "id": 16777267, "type": 10003, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } : { "id": 16777265, "type": 10003, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Text.debugLine("pages/DialogComponent.ets(51:7)");
            Text.fontSize('16vp');
            Text.fontColor(this.curIndex === index ? '#018F90' : Color.Gray);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
    }
    aboutToAppear() {
        this.inputAmount = this.newAccount.amount.toString();
        this.curIndex = this.newAccount.accountType;
        this.curType = this.newAccount.typeText;
    }
    selectAccount(item) {
        this.newAccount.accountType = item.accountType;
        this.newAccount.typeText = item.typeText;
        this.curType = item.typeText;
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/DialogComponent.ets(77:5)");
            Column.width(CommonConstants.FULL_WIDTH);
            Column.height(CommonConstants.DIALOG_HEIGHT);
            Column.borderRadius({ topLeft: { "id": 16777246, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" }, topRight: { "id": 16777246, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } });
            Column.backgroundColor(Color.White);
            Column.align(Alignment.BottomEnd);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ['half.png'], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Image.debugLine("pages/DialogComponent.ets(78:7)");
            Image.width('64vp');
            Image.height('24vp');
            Image.onClick(() => {
                var _a;
                (_a = this.controller) === null || _a === void 0 ? void 0 : _a.close();
            });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Tabs.create({ barPosition: BarPosition.Start, index: this.curIndex });
            Tabs.debugLine("pages/DialogComponent.ets(85:7)");
            Tabs.width(CommonConstants.FULL_WIDTH);
            Tabs.height(CommonConstants.TABS_HEIGHT);
            Tabs.vertical(false);
            Tabs.barMode(BarMode.Fixed);
            Tabs.onChange((index) => {
                this.curIndex = index;
            });
            if (!isInitialRender) {
                Tabs.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TabContent.create(() => {
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Scroll.create(this.scroller);
                    Scroll.debugLine("pages/DialogComponent.ets(89:11)");
                    Scroll.scrollable(ScrollDirection.Horizontal);
                    Scroll.scrollBar(BarState.Off);
                    if (!isInitialRender) {
                        Scroll.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Row.create();
                    Row.debugLine("pages/DialogComponent.ets(90:13)");
                    if (!isInitialRender) {
                        Row.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    ForEach.create();
                    const forEachItemGenFunction = _item => {
                        const item = _item;
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Column.create();
                            Column.debugLine("pages/DialogComponent.ets(92:17)");
                            Column.width({ "id": 16777231, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
                            Column.aspectRatio(CommonConstants.FULL_SIZE);
                            Column.padding({ top: { "id": 16777240, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } });
                            Column.margin({ top: { "id": 16777242, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" }, left: { "id": 16777240, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } });
                            Column.align(Alignment.TopStart);
                            Column.backgroundColor(this.curType === item.typeText ? '#018F90' : '#FFF1F3F5');
                            Column.borderRadius({ "id": 16777254, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
                            Column.onClick(() => {
                                this.selectAccount(item);
                            });
                            if (!isInitialRender) {
                                Column.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Image.create(item.icon);
                            Image.debugLine("pages/DialogComponent.ets(93:19)");
                            Image.width({ "id": 16777250, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
                            Image.aspectRatio(CommonConstants.FULL_SIZE);
                            Image.fillColor(this.curType === item.typeText ? Color.White : '#018F90');
                            if (!isInitialRender) {
                                Image.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(item.typeText);
                            Text.debugLine("pages/DialogComponent.ets(98:19)");
                            Text.fontSize({ "id": 16777249, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
                            Text.fontColor(this.curType === item.typeText ? Color.White : '#018F90');
                            Text.margin({ top: { "id": 16777244, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } });
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        Column.pop();
                    };
                    this.forEachUpdateFunction(elmtId, this.payList, forEachItemGenFunction);
                    if (!isInitialRender) {
                        ForEach.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                ForEach.pop();
                Row.pop();
                Scroll.pop();
            });
            TabContent.tabBar({ builder: () => {
                    this.TabBuilder.call(this, 0);
                } });
            TabContent.margin({ bottom: { "id": 16777239, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } });
            TabContent.debugLine("pages/DialogComponent.ets(88:9)");
            if (!isInitialRender) {
                //支出
                TabContent.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TabContent.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TabContent.create(() => {
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Scroll.create(this.scroller);
                    Scroll.debugLine("pages/DialogComponent.ets(124:11)");
                    Scroll.scrollable(ScrollDirection.Horizontal);
                    Scroll.scrollBar(BarState.Off);
                    if (!isInitialRender) {
                        Scroll.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Row.create();
                    Row.debugLine("pages/DialogComponent.ets(125:13)");
                    if (!isInitialRender) {
                        Row.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    ForEach.create();
                    const forEachItemGenFunction = _item => {
                        const item = _item;
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Column.create();
                            Column.debugLine("pages/DialogComponent.ets(127:17)");
                            Column.width({ "id": 16777231, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
                            Column.aspectRatio(CommonConstants.FULL_SIZE);
                            Column.padding({ top: { "id": 16777240, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } });
                            Column.margin({ top: { "id": 16777242, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" }, left: { "id": 16777240, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } });
                            Column.align(Alignment.TopStart);
                            Column.backgroundColor(this.curType === item.typeText ? '#018F90' : '#FFF1F3F5');
                            Column.borderRadius({ "id": 16777254, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
                            Column.onClick(() => {
                                this.selectAccount(item);
                            });
                            if (!isInitialRender) {
                                Column.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Image.create(item.icon);
                            Image.debugLine("pages/DialogComponent.ets(128:19)");
                            Image.width({ "id": 16777250, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
                            Image.aspectRatio(CommonConstants.FULL_SIZE);
                            Image.fillColor(this.curType === item.typeText ? Color.White : '#018F90');
                            if (!isInitialRender) {
                                Image.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(item.typeText);
                            Text.debugLine("pages/DialogComponent.ets(133:19)");
                            Text.fontSize({ "id": 16777249, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
                            Text.fontColor(this.curType === item.typeText ? Color.White : '#018F90');
                            Text.margin({ top: { "id": 16777244, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } });
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        Column.pop();
                    };
                    this.forEachUpdateFunction(elmtId, this.earnList, forEachItemGenFunction);
                    if (!isInitialRender) {
                        ForEach.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                ForEach.pop();
                Row.pop();
                Scroll.pop();
            });
            TabContent.tabBar({ builder: () => {
                    this.TabBuilder.call(this, 1);
                } });
            TabContent.margin({ bottom: { "id": 16777239, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } });
            TabContent.debugLine("pages/DialogComponent.ets(123:9)");
            if (!isInitialRender) {
                //收入
                TabContent.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TabContent.pop();
        Tabs.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/DialogComponent.ets(166:7)");
            Column.width(CommonConstants.FULL_WIDTH);
            Column.padding({ left: { "id": 16777240, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" }, right: { "id": 16777240, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create({ "id": 16777263, "type": 10003, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Text.debugLine("pages/DialogComponent.ets(167:9)");
            Text.width(CommonConstants.FULL_WIDTH);
            Text.fontSize({ "id": 16777248, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Text.fontColor(Color.Black);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/DialogComponent.ets(172:9)");
            Column.height({ "id": 16777233, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Column.padding({ top: { "id": 16777243, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" }, bottom: { "id": 16777241, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } });
            Column.borderWidth({ bottom: CommonConstants.FULL_SIZE });
            Column.borderColor('#33182431');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //金额
            TextInput.create({
                placeholder: { "id": 16777266, "type": 10003, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" },
                text: this.newAccount.amount === 0 ? this.inputAmount : this.newAccount.amount.toString()
            });
            TextInput.debugLine("pages/DialogComponent.ets(174:11)");
            //金额
            TextInput.padding({ left: CommonConstants.MINIMUM_SIZE });
            //金额
            TextInput.borderRadius(CommonConstants.MINIMUM_SIZE);
            //金额
            TextInput.backgroundColor(Color.White);
            //金额
            TextInput.type(InputType.Number);
            //金额
            TextInput.onChange((value) => {
                this.inputAmount = value;
            });
            //金额
            TextInput.onSubmit(() => {
                this.newAccount.amount = Number.parseInt(this.inputAmount);
            });
            if (!isInitialRender) {
                //金额
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Column.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //日期or时间
            Text.create('时间');
            Text.debugLine("pages/DialogComponent.ets(198:7)");
            //日期or时间
            Text.width('100%');
            //日期or时间
            Text.fontSize('20vp');
            //日期or时间
            Text.fontColor(Color.Black);
            //日期or时间
            Text.padding({ left: { "id": 16777240, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" }, right: { "id": 16777240, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" }, top: '5vp' });
            if (!isInitialRender) {
                //日期or时间
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //日期or时间
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/DialogComponent.ets(204:7)");
            Column.height('50vp');
            Column.width('100%');
            Column.padding({ top: '15vp', bottom: '11vp' });
            Column.borderWidth({ bottom: CommonConstants.FULL_SIZE });
            Column.borderColor('#3348478C');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.newAccount.day);
            Text.debugLine("pages/DialogComponent.ets(205:9)");
            Text.padding({ left: CommonConstants.MINIMUM_SIZE });
            Text.borderRadius(CommonConstants.MINIMUM_SIZE);
            Text.backgroundColor('#F1F3F5');
            Text.fontSize('20vp');
            Text.onClick(() => {
                let cur_date = new Date();
                this.selected_date = cur_date;
                DatePickerDialog.show({
                    start: new Date("2022-1-1"),
                    end: new Date("2024-1-1"),
                    selected: this.selected_date,
                    onAccept: (value) => {
                        this.selected_date.setFullYear(value.year, value.month, value.day);
                        this.newAccount.day = value.year.toString() + '年'
                            + (value.month + 1).toString() + '月'
                            + value.day.toString() + '日';
                        this.newAccount.year = value.year.toString();
                        this.newAccount.month = value.year.toString() + '-' + (value.month + 1).toString();
                        this.newAccount.day = value.year.toString() + '年' + (value.month + 1).toString() + '月' + value.day.toString() + '日';
                        console.info("###DatePickerDialog Accept: " + JSON.stringify(value));
                    },
                    onCancel: () => {
                        console.info("###DatePickerDialog: Cancel()");
                    },
                    onChange: () => {
                        console.info("###DatePickerDialog: onChange()");
                    }
                });
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //备注
            Column.create();
            Column.debugLine("pages/DialogComponent.ets(243:7)");
            //备注
            Column.width(CommonConstants.FULL_WIDTH);
            //备注
            Column.padding({ left: { "id": 16777240, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" }, right: { "id": 16777240, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } });
            if (!isInitialRender) {
                //备注
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('备注');
            Text.debugLine("pages/DialogComponent.ets(244:9)");
            Text.width(CommonConstants.FULL_WIDTH);
            Text.fontSize({ "id": 16777248, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Text.fontColor(Color.Black);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({
                placeholder: '备注是...',
                text: this.newAccount.reminder === '' ? this.inputRemind : this.newAccount.reminder
            });
            TextInput.debugLine("pages/DialogComponent.ets(249:9)");
            TextInput.padding({ left: CommonConstants.MINIMUM_SIZE });
            TextInput.borderRadius(CommonConstants.MINIMUM_SIZE);
            TextInput.backgroundColor(Color.White);
            TextInput.type(InputType.Normal);
            TextInput.onChange((value) => {
                this.inputRemind = value;
            });
            TextInput.onSubmit(() => {
                this.newAccount.reminder = this.inputRemind;
            });
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //备注
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //确定
            Column.create();
            Column.debugLine("pages/DialogComponent.ets(268:7)");
            //确定
            Column.layoutWeight(CommonConstants.FULL_SIZE);
            //确定
            Column.padding({
                bottom: { "id": 16777246, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" },
                left: { "id": 16777246, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" },
                right: { "id": 16777246, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" }
            });
            //确定
            Column.justifyContent(FlexAlign.End);
            if (!isInitialRender) {
                //确定
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild();
            Button.debugLine("pages/DialogComponent.ets(269:9)");
            Button.width(CommonConstants.FULL_WIDTH);
            Button.height({ "id": 16777232, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Button.onClick(() => {
                var _a;
                if (this.newAccount.typeText === '' || this.curIndex !== this.newAccount.accountType) {
                    prompt.showToast({ message: CommonConstants.TOAST_TEXT_1, bottom: CommonConstants.PROMPT_BOTTOM });
                }
                else {
                    let regex = new RegExp('[1-9][0-9]*');
                    let matchValue = this.inputAmount.match(regex);
                    if (matchValue !== null && matchValue[0] === this.inputAmount) {
                        this.newAccount.amount = Number(this.inputAmount);
                        this.confirm && this.confirm(this.isInsert, ObservedObject.GetRawObject(this.newAccount));
                        (_a = this.controller) === null || _a === void 0 ? void 0 : _a.close();
                    }
                    else {
                        prompt.showToast({ message: CommonConstants.TOAST_TEXT_2, bottom: CommonConstants.PROMPT_BOTTOM });
                    }
                }
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create({ "id": 16777262, "type": 10003, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Text.debugLine("pages/DialogComponent.ets(270:11)");
            Text.fontSize({ "id": 16777247, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Text.fontColor(Color.White);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Button.pop();
        //确定
        Column.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=DialogComponent.js.map