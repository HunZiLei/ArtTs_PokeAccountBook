import router from '@ohos:router';
import ToBuyData from '@bundle:com.example.accountbook/entry/ets/bean/ToBuyData';
import Check_Access from '@bundle:com.example.accountbook/entry/ets/service/Dectector';
import Request_Permission_From_Users from '@bundle:com.example.accountbook/entry/ets/service/Applicant';
import { toBuyDialog } from '@bundle:com.example.accountbook/entry/ets/pages/toBuyDialog';
class ToBuyPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        var _a, _b;
        super(parent, __localStorage, elmtId);
        this.settings = new RenderingContextSettings(true);
        this.context = new CanvasRenderingContext2D(this.settings);
        this.offContext = new OffscreenCanvasRenderingContext2D(600, 600, this.settings);
        this.__xPos = new ObservedPropertyObjectPU(new Array(30, 80, 130, 180, 230, 280, 330), this, "xPos");
        this.__params = new ObservedPropertyObjectPU(router.getParams(), this, "params");
        this.__yPos = new ObservedPropertyObjectPU(((_a = this.params) === null || _a === void 0 ? void 0 : _a['yPos']) ? (_b = this.params) === null || _b === void 0 ? void 0 : _b['yPos'] : new Array(1, 1, 1, 1, 1, 1, 1), this, "yPos");
        this.__toBuyList = new ObservedPropertyObjectPU([new ToBuyData('书包', false, null), new ToBuyData('蜡笔', false, new Date('2023-11-26')),
            new ToBuyData('羽毛球拍', false, new Date('2023-11-25')), new ToBuyData('华为手机', true, new Date('2023-11-30'))], this, "toBuyList");
        this.__hasChanged = new ObservedPropertySimplePU(false, this, "hasChanged");
        this.__index = new ObservedPropertySimplePU(-1, this, "index");
        this.__inserting = new ObservedPropertySimplePU(true, this, "inserting");
        this.__newToBuy = new ObservedPropertyObjectPU({
            thing: '',
            isDone: false,
            ddl: null
        }, this, "newToBuy");
        this.netContext = getContext(this);
        this.controller = undefined;
        this.dialogController = new CustomDialogController({
            builder: () => {
                let jsDialog = new toBuyDialog(this, {
                    isInsert: this.__inserting,
                    newToBuy: this.__newToBuy,
                    confirm: (isInsert, newToBuy) => this.accept(isInsert, newToBuy)
                });
                jsDialog.setController(this.
                /*页面跳转-controller*/
                dialogController);
                ViewPU.create(jsDialog);
            },
            customStyle: true,
            alignment: DialogAlignment.Bottom
        }, this);
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.settings !== undefined) {
            this.settings = params.settings;
        }
        if (params.context !== undefined) {
            this.context = params.context;
        }
        if (params.offContext !== undefined) {
            this.offContext = params.offContext;
        }
        if (params.xPos !== undefined) {
            this.xPos = params.xPos;
        }
        if (params.params !== undefined) {
            this.params = params.params;
        }
        if (params.yPos !== undefined) {
            this.yPos = params.yPos;
        }
        if (params.toBuyList !== undefined) {
            this.toBuyList = params.toBuyList;
        }
        if (params.hasChanged !== undefined) {
            this.hasChanged = params.hasChanged;
        }
        if (params.index !== undefined) {
            this.index = params.index;
        }
        if (params.inserting !== undefined) {
            this.inserting = params.inserting;
        }
        if (params.newToBuy !== undefined) {
            this.newToBuy = params.newToBuy;
        }
        if (params.netContext !== undefined) {
            this.netContext = params.netContext;
        }
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
        if (params.dialogController !== undefined) {
            this.dialogController = params.dialogController;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__xPos.purgeDependencyOnElmtId(rmElmtId);
        this.__params.purgeDependencyOnElmtId(rmElmtId);
        this.__yPos.purgeDependencyOnElmtId(rmElmtId);
        this.__toBuyList.purgeDependencyOnElmtId(rmElmtId);
        this.__hasChanged.purgeDependencyOnElmtId(rmElmtId);
        this.__index.purgeDependencyOnElmtId(rmElmtId);
        this.__inserting.purgeDependencyOnElmtId(rmElmtId);
        this.__newToBuy.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__xPos.aboutToBeDeleted();
        this.__params.aboutToBeDeleted();
        this.__yPos.aboutToBeDeleted();
        this.__toBuyList.aboutToBeDeleted();
        this.__hasChanged.aboutToBeDeleted();
        this.__index.aboutToBeDeleted();
        this.__inserting.aboutToBeDeleted();
        this.__newToBuy.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get xPos() {
        return this.__xPos.get();
    }
    set xPos(newValue) {
        this.__xPos.set(newValue);
    }
    get params() {
        return this.__params.get();
    }
    set params(newValue) {
        this.__params.set(newValue);
    }
    get yPos() {
        return this.__yPos.get();
    }
    set yPos(newValue) {
        this.__yPos.set(newValue);
    }
    get toBuyList() {
        return this.__toBuyList.get();
    }
    set toBuyList(newValue) {
        this.__toBuyList.set(newValue);
    }
    get hasChanged() {
        return this.__hasChanged.get();
    }
    set hasChanged(newValue) {
        this.__hasChanged.set(newValue);
    }
    get index() {
        return this.__index.get();
    }
    set index(newValue) {
        this.__index.set(newValue);
    }
    get inserting() {
        return this.__inserting.get();
    }
    set inserting(newValue) {
        this.__inserting.set(newValue);
    }
    get newToBuy() {
        return this.__newToBuy.get();
    }
    set newToBuy(newValue) {
        this.__newToBuy.set(newValue);
    }
    /*数据库相关函数*/
    getRealDate(date) {
        return date.getFullYear().toString() + '-' + (date.getMonth() + 1).toString() + '-' + date.getDate().toString();
    }
    accept(isInsert, newToBuy) {
        if (isInsert) { //插入数据项
            this.toBuyList.push(newToBuy);
        }
        else {
            let list = this.toBuyList;
            this.toBuyList = [];
            list[this.index] = newToBuy;
            this.toBuyList = list;
            this.index = -1;
        }
    }
    selectListItem(item) {
        this.inserting = false;
        //记录坐标
        this.index = this.toBuyList.indexOf(item);
        //刷新newToBuy
        this.newToBuy = this.toBuyList[this.index];
    }
    /*网络请求相关*/
    detect() {
        let res = Check_Access();
        if (res) {
            return true;
        }
        else {
            return false;
        }
    }
    //申请获取网络权限
    async apply() {
        let res = await Request_Permission_From_Users(this.netContext);
    }
    /*页面跳转的函数*/
    jumpDetailPage() {
        console.info("###ToBuyPage-yPos: " + this.yPos[0] + "-" + this.yPos[1]);
        router.pushUrl({
            url: 'pages/Index',
            params: {
                yPos: this.yPos
            }
        }, router.RouterMode.Single, (err) => {
            if (err) {
                console.error(`###Invoke pushUrl failed, code is ${err.code}, message is ${err.message}`);
                return;
            }
            console.info('###Invoke pushUrl succeeded.');
        });
    }
    jumpSumPage() {
        console.info("###ToBuyPage-yPos: " + this.yPos[0] + "-" + this.yPos[1]);
        router.pushUrl({
            url: 'pages/sumPage',
            params: {
                yPos: this.yPos
            }
        }, router.RouterMode.Single, (err) => {
            if (err) {
                console.error(`###Invoke pushUrl failed, code is ${err.code}, message is ${err.message}`);
                return;
            }
            console.info('###Invoke pushUrl succeeded.');
        });
    }
    jumpToBuyPage() {
        console.info("###ToBuyPage-yPos: " + this.yPos[0] + "-" + this.yPos[1]);
        router.pushUrl({
            url: 'pages/tuBuyPage',
            params: {
                yPos: this.yPos
            }
        }, router.RouterMode.Single, (err) => {
            if (err) {
                console.error(`###Invoke pushUrl failed, code is ${err.code}, message is ${err.message}`);
                return;
            }
            console.info('###Invoke pushUrl succeeded.');
        });
    }
    jumpMePage() {
        console.info("###ToBuyPage-yPos: " + this.yPos[0] + "-" + this.yPos[1]);
        router.pushUrl({
            url: 'pages/mePage' // 目标url
        }, router.RouterMode.Single, (err) => {
            if (err) {
                console.error(`###Invoke pushUrl failed, code is ${err.code}, message is ${err.message}`);
                return;
            }
            console.info('###Invoke pushUrl succeeded.');
        });
    }
    jumpWebPage(thing) {
        router.pushUrl({
            url: 'pages/webPage',
            params: {
                name: thing
            }
        }, router.RouterMode.Single, (err) => {
            if (err) {
                console.error(`###Invoke pushUrl failed, code is ${err.code}, message is ${err.message}`);
                return;
            }
            console.info('###Invoke pushUrl succeeded.');
        });
    }
    jumpWebPage_jing(thing) {
        router.pushUrl({
            url: 'pages/webPage_jing',
            params: {
                name: thing
            }
        }, router.RouterMode.Single, (err) => {
            if (err) {
                console.error(`###Invoke pushUrl failed, code is ${err.code}, message is ${err.message}`);
                return;
            }
            console.info('###Invoke pushUrl succeeded.');
        });
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create();
            Stack.debugLine("pages/toBuyPage.ets(187:5)");
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/toBuyPage.ets(188:7)");
            Column.width('100%');
            Column.height('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //标题 & 编辑按钮
            Row.create();
            Row.debugLine("pages/toBuyPage.ets(190:9)");
            //标题 & 编辑按钮
            Row.sharedTransition('title', { duration: 500, curve: Curve.Linear });
            //标题 & 编辑按钮
            Row.backgroundColor({ "id": 16777219, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            //标题 & 编辑按钮
            Row.position({ x: 0, y: 0 });
            //标题 & 编辑按钮
            Row.width('100%');
            //标题 & 编辑按钮
            Row.height('20%');
            //标题 & 编辑按钮
            Row.justifyContent(FlexAlign.SpaceBetween);
            if (!isInitialRender) {
                //标题 & 编辑按钮
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create({ "id": 16777257, "type": 10003, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Text.debugLine("pages/toBuyPage.ets(191:11)");
            Text.fontColor(Color.White);
            Text.height(30);
            Text.fontSize(30);
            Text.margin({ left: 24, bottom: '50vp' });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        //标题 & 编辑按钮
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            /*图表部分
            Flex({ direction: FlexDirection.Column, alignItems: ItemAlign.Center, justifyContent: FlexAlign.Center }) {
              Canvas(this.context)
                .width('100%')
                .height('100%')
                .backgroundColor('')
                .onReady(() =>{
                  this.offContext.lineWidth = 3;
                  this.offContext.beginPath();
                  this.offContext.lineCap = 'round';
                  this.offContext.lineJoin = 'round';
                  this.offContext.strokeStyle = '#ECFFE9';
    
                  this.offContext.moveTo(this.xPos[0], this.yPos[0]);
                  let tot = 0;
                  for(let i = 0; i<7; i++){
                    tot += this.yPos[i];
                  }
    
                  //画首个点
                  let path: Path2D = new Path2D();
                  path.arc(this.xPos[0],60-this.yPos[0]/tot*60,5,0,360);
                  this.offContext.fillStyle = '#ECFFE9'
                  this.offContext.fill(path);
                  //画其余点
                  this.offContext.moveTo(this.xPos[0], 60-this.yPos[0]/tot*60);
                  for(let i = 1; i<7; i++){
                    let path: Path2D = new Path2D();
                    path.arc(this.xPos[i],60-this.yPos[i]/tot*60,5,0,360);
                    this.offContext.fill(path);
                    this.offContext.lineTo(this.xPos[i], 60-this.yPos[i]/tot*60);
                    //this.offContext.quadraticCurveTo(this.xPos[i+1],this.yPos[i+1],this.xPos[i+1],this.yPos[i+1])
                  }
    
                  this.offContext.stroke();
                  var image = this.offContext.transferToImageBitmap();
                  this.context.transferFromImageBitmap(image);
                })
            }
            .width('100%')
            .height('8%')
            .position({x:0,y:'10%'})
            图表部分*/
            //待办事项的展示
            List.create();
            List.debugLine("pages/toBuyPage.ets(249:9)");
            /*图表部分
            Flex({ direction: FlexDirection.Column, alignItems: ItemAlign.Center, justifyContent: FlexAlign.Center }) {
              Canvas(this.context)
                .width('100%')
                .height('100%')
                .backgroundColor('')
                .onReady(() =>{
                  this.offContext.lineWidth = 3;
                  this.offContext.beginPath();
                  this.offContext.lineCap = 'round';
                  this.offContext.lineJoin = 'round';
                  this.offContext.strokeStyle = '#ECFFE9';
    
                  this.offContext.moveTo(this.xPos[0], this.yPos[0]);
                  let tot = 0;
                  for(let i = 0; i<7; i++){
                    tot += this.yPos[i];
                  }
    
                  //画首个点
                  let path: Path2D = new Path2D();
                  path.arc(this.xPos[0],60-this.yPos[0]/tot*60,5,0,360);
                  this.offContext.fillStyle = '#ECFFE9'
                  this.offContext.fill(path);
                  //画其余点
                  this.offContext.moveTo(this.xPos[0], 60-this.yPos[0]/tot*60);
                  for(let i = 1; i<7; i++){
                    let path: Path2D = new Path2D();
                    path.arc(this.xPos[i],60-this.yPos[i]/tot*60,5,0,360);
                    this.offContext.fill(path);
                    this.offContext.lineTo(this.xPos[i], 60-this.yPos[i]/tot*60);
                    //this.offContext.quadraticCurveTo(this.xPos[i+1],this.yPos[i+1],this.xPos[i+1],this.yPos[i+1])
                  }
    
                  this.offContext.stroke();
                  var image = this.offContext.transferToImageBitmap();
                  this.context.transferFromImageBitmap(image);
                })
            }
            .width('100%')
            .height('8%')
            .position({x:0,y:'10%'})
            图表部分*/
            //待办事项的展示
            List.position({ x: '1%', y: '20%' });
            if (!isInitialRender) {
                /*图表部分
                Flex({ direction: FlexDirection.Column, alignItems: ItemAlign.Center, justifyContent: FlexAlign.Center }) {
                  Canvas(this.context)
                    .width('100%')
                    .height('100%')
                    .backgroundColor('')
                    .onReady(() =>{
                      this.offContext.lineWidth = 3;
                      this.offContext.beginPath();
                      this.offContext.lineCap = 'round';
                      this.offContext.lineJoin = 'round';
                      this.offContext.strokeStyle = '#ECFFE9';
        
                      this.offContext.moveTo(this.xPos[0], this.yPos[0]);
                      let tot = 0;
                      for(let i = 0; i<7; i++){
                        tot += this.yPos[i];
                      }
        
                      //画首个点
                      let path: Path2D = new Path2D();
                      path.arc(this.xPos[0],60-this.yPos[0]/tot*60,5,0,360);
                      this.offContext.fillStyle = '#ECFFE9'
                      this.offContext.fill(path);
                      //画其余点
                      this.offContext.moveTo(this.xPos[0], 60-this.yPos[0]/tot*60);
                      for(let i = 1; i<7; i++){
                        let path: Path2D = new Path2D();
                        path.arc(this.xPos[i],60-this.yPos[i]/tot*60,5,0,360);
                        this.offContext.fill(path);
                        this.offContext.lineTo(this.xPos[i], 60-this.yPos[i]/tot*60);
                        //this.offContext.quadraticCurveTo(this.xPos[i+1],this.yPos[i+1],this.xPos[i+1],this.yPos[i+1])
                      }
        
                      this.offContext.stroke();
                      var image = this.offContext.transferToImageBitmap();
                      this.context.transferFromImageBitmap(image);
                    })
                }
                .width('100%')
                .height('8%')
                .position({x:0,y:'10%'})
                图表部分*/
                //待办事项的展示
                List.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                {
                    const isLazyCreate = true;
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        ListItem.create(deepRenderFunction, isLazyCreate);
                        ListItem.debugLine("pages/toBuyPage.ets(251:13)");
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const observedShallowRender = () => {
                        this.observeComponentCreation(itemCreation);
                        ListItem.pop();
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation(itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Row.create();
                            Row.debugLine("pages/toBuyPage.ets(252:15)");
                            Row.onClick(() => {
                                this.selectListItem(item);
                                this.dialogController.open();
                            });
                            if (!isInitialRender) {
                                Row.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            //勾选框
                            Toggle.create({ type: ToggleType.Checkbox, isOn: item.isDone ? true : false });
                            Toggle.debugLine("pages/toBuyPage.ets(254:17)");
                            //勾选框
                            Toggle.width('25vp');
                            //勾选框
                            Toggle.selectedColor('#6E948A');
                            //勾选框
                            Toggle.onChange((isOn) => {
                                if (isOn) {
                                    item.isDone = true;
                                }
                            });
                            if (!isInitialRender) {
                                //勾选框
                                Toggle.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        //勾选框
                        Toggle.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            //空白符
                            Blank.create();
                            Blank.debugLine("pages/toBuyPage.ets(264:17)");
                            //空白符
                            Blank.layoutWeight(1);
                            if (!isInitialRender) {
                                //空白符
                                Blank.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        //空白符
                        Blank.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            //待购商品
                            Text.create(item.thing.length > 20 ? item.thing.substring(0, 20) + '...' : item.thing);
                            Text.debugLine("pages/toBuyPage.ets(268:17)");
                            //待购商品
                            Text.fontColor(item.isDone && this.hasChanged ? Color.Gray : Color.Black);
                            //待购商品
                            Text.fontSize('20vp');
                            if (!isInitialRender) {
                                //待购商品
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        //待购商品
                        Text.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            //空白符
                            Blank.create();
                            Blank.debugLine("pages/toBuyPage.ets(273:17)");
                            //空白符
                            Blank.layoutWeight(18);
                            if (!isInitialRender) {
                                //空白符
                                Blank.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        //空白符
                        Blank.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            If.create();
                            //截止时间
                            if (item.ddl != null) {
                                this.ifElseBranchUpdateFunction(0, () => {
                                    this.observeComponentCreation((elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        //Text(item.ddl.toDateString())
                                        Text.create(((item.ddl.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)) > 6 ? this.getRealDate(item.ddl) : ((item.ddl.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)).toFixed(1).toString() + '天');
                                        Text.debugLine("pages/toBuyPage.ets(279:19)");
                                        //Text(item.ddl.toDateString())
                                        Text.fontSize('20vp');
                                        //Text(item.ddl.toDateString())
                                        Text.fontColor(((item.ddl.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)) > 5 ? { "id": 16777219, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } : Color.Red);
                                        //Text(item.ddl.toDateString())
                                        Text.markAnchor({ x: '20vp' });
                                        if (!isInitialRender) {
                                            //Text(item.ddl.toDateString())
                                            Text.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    });
                                    //Text(item.ddl.toDateString())
                                    Text.pop();
                                });
                            }
                            else {
                                If.branchId(1);
                            }
                            if (!isInitialRender) {
                                If.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        If.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Blank.create();
                            Blank.debugLine("pages/toBuyPage.ets(285:17)");
                            Blank.layoutWeight(1);
                            if (!isInitialRender) {
                                Blank.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Blank.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            //淘宝按钮
                            Button.createWithChild({ type: ButtonType.Capsule, stateEffect: true });
                            Button.debugLine("pages/toBuyPage.ets(289:17)");
                            //淘宝按钮
                            Button.markAnchor({ x: '20vp', y: 0 });
                            //淘宝按钮
                            Button.width('40vp');
                            //淘宝按钮
                            Button.height('40vp');
                            //淘宝按钮
                            Button.backgroundColor(Color.White);
                            //淘宝按钮
                            Button.onClick(() => {
                                //检查网络权限
                                if (this.detect()) {
                                    this.apply();
                                    console.info('###Try to get web');
                                }
                                //跳转到webPage
                                this.jumpWebPage(item.thing);
                            });
                            if (!isInitialRender) {
                                //淘宝按钮
                                Button.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Image.create({ "id": 0, "type": 30000, params: ['toBuyPage_taoBao.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" });
                            Image.debugLine("pages/toBuyPage.ets(290:19)");
                            Image.width('40vp');
                            Image.height('40vp');
                            Image.fillColor(item.isDone && this.hasChanged ? Color.Gray : { "id": 16777219, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
                            if (!isInitialRender) {
                                Image.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        //淘宝按钮
                        Button.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            //京东按钮
                            Button.createWithChild({ type: ButtonType.Capsule, stateEffect: true });
                            Button.debugLine("pages/toBuyPage.ets(310:17)");
                            //京东按钮
                            Button.markAnchor({ x: '20vp', y: 0 });
                            //京东按钮
                            Button.width('40vp');
                            //京东按钮
                            Button.height('40vp');
                            //京东按钮
                            Button.backgroundColor(Color.White);
                            //京东按钮
                            Button.onClick(() => {
                                //检查网络权限
                                if (this.detect()) {
                                    this.apply();
                                }
                                //跳转到webPage
                                this.jumpWebPage_jing(item.thing);
                            });
                            if (!isInitialRender) {
                                //京东按钮
                                Button.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Image.create({ "id": 0, "type": 30000, params: ['toBuyPage_jingdong.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" });
                            Image.debugLine("pages/toBuyPage.ets(311:19)");
                            Image.width('40vp');
                            Image.height('40vp');
                            Image.fillColor(item.isDone && this.hasChanged ? Color.Gray : { "id": 16777219, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
                            if (!isInitialRender) {
                                Image.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        //京东按钮
                        Button.pop();
                        Row.pop();
                        ListItem.pop();
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.updateFuncByElmtId.set(elmtId, itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Row.create();
                            Row.debugLine("pages/toBuyPage.ets(252:15)");
                            Row.onClick(() => {
                                this.selectListItem(item);
                                this.dialogController.open();
                            });
                            if (!isInitialRender) {
                                Row.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            //勾选框
                            Toggle.create({ type: ToggleType.Checkbox, isOn: item.isDone ? true : false });
                            Toggle.debugLine("pages/toBuyPage.ets(254:17)");
                            //勾选框
                            Toggle.width('25vp');
                            //勾选框
                            Toggle.selectedColor('#6E948A');
                            //勾选框
                            Toggle.onChange((isOn) => {
                                if (isOn) {
                                    item.isDone = true;
                                }
                            });
                            if (!isInitialRender) {
                                //勾选框
                                Toggle.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        //勾选框
                        Toggle.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            //空白符
                            Blank.create();
                            Blank.debugLine("pages/toBuyPage.ets(264:17)");
                            //空白符
                            Blank.layoutWeight(1);
                            if (!isInitialRender) {
                                //空白符
                                Blank.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        //空白符
                        Blank.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            //待购商品
                            Text.create(item.thing.length > 20 ? item.thing.substring(0, 20) + '...' : item.thing);
                            Text.debugLine("pages/toBuyPage.ets(268:17)");
                            //待购商品
                            Text.fontColor(item.isDone && this.hasChanged ? Color.Gray : Color.Black);
                            //待购商品
                            Text.fontSize('20vp');
                            if (!isInitialRender) {
                                //待购商品
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        //待购商品
                        Text.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            //空白符
                            Blank.create();
                            Blank.debugLine("pages/toBuyPage.ets(273:17)");
                            //空白符
                            Blank.layoutWeight(18);
                            if (!isInitialRender) {
                                //空白符
                                Blank.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        //空白符
                        Blank.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            If.create();
                            //截止时间
                            if (item.ddl != null) {
                                this.ifElseBranchUpdateFunction(0, () => {
                                    this.observeComponentCreation((elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        //Text(item.ddl.toDateString())
                                        Text.create(((item.ddl.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)) > 6 ? this.getRealDate(item.ddl) : ((item.ddl.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)).toFixed(1).toString() + '天');
                                        Text.debugLine("pages/toBuyPage.ets(279:19)");
                                        //Text(item.ddl.toDateString())
                                        Text.fontSize('20vp');
                                        //Text(item.ddl.toDateString())
                                        Text.fontColor(((item.ddl.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)) > 5 ? { "id": 16777219, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } : Color.Red);
                                        //Text(item.ddl.toDateString())
                                        Text.markAnchor({ x: '20vp' });
                                        if (!isInitialRender) {
                                            //Text(item.ddl.toDateString())
                                            Text.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    });
                                    //Text(item.ddl.toDateString())
                                    Text.pop();
                                });
                            }
                            else {
                                If.branchId(1);
                            }
                            if (!isInitialRender) {
                                If.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        If.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Blank.create();
                            Blank.debugLine("pages/toBuyPage.ets(285:17)");
                            Blank.layoutWeight(1);
                            if (!isInitialRender) {
                                Blank.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Blank.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            //淘宝按钮
                            Button.createWithChild({ type: ButtonType.Capsule, stateEffect: true });
                            Button.debugLine("pages/toBuyPage.ets(289:17)");
                            //淘宝按钮
                            Button.markAnchor({ x: '20vp', y: 0 });
                            //淘宝按钮
                            Button.width('40vp');
                            //淘宝按钮
                            Button.height('40vp');
                            //淘宝按钮
                            Button.backgroundColor(Color.White);
                            //淘宝按钮
                            Button.onClick(() => {
                                //检查网络权限
                                if (this.detect()) {
                                    this.apply();
                                    console.info('###Try to get web');
                                }
                                //跳转到webPage
                                this.jumpWebPage(item.thing);
                            });
                            if (!isInitialRender) {
                                //淘宝按钮
                                Button.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Image.create({ "id": 0, "type": 30000, params: ['toBuyPage_taoBao.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" });
                            Image.debugLine("pages/toBuyPage.ets(290:19)");
                            Image.width('40vp');
                            Image.height('40vp');
                            Image.fillColor(item.isDone && this.hasChanged ? Color.Gray : { "id": 16777219, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
                            if (!isInitialRender) {
                                Image.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        //淘宝按钮
                        Button.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            //京东按钮
                            Button.createWithChild({ type: ButtonType.Capsule, stateEffect: true });
                            Button.debugLine("pages/toBuyPage.ets(310:17)");
                            //京东按钮
                            Button.markAnchor({ x: '20vp', y: 0 });
                            //京东按钮
                            Button.width('40vp');
                            //京东按钮
                            Button.height('40vp');
                            //京东按钮
                            Button.backgroundColor(Color.White);
                            //京东按钮
                            Button.onClick(() => {
                                //检查网络权限
                                if (this.detect()) {
                                    this.apply();
                                }
                                //跳转到webPage
                                this.jumpWebPage_jing(item.thing);
                            });
                            if (!isInitialRender) {
                                //京东按钮
                                Button.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Image.create({ "id": 0, "type": 30000, params: ['toBuyPage_jingdong.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" });
                            Image.debugLine("pages/toBuyPage.ets(311:19)");
                            Image.width('40vp');
                            Image.height('40vp');
                            Image.fillColor(item.isDone && this.hasChanged ? Color.Gray : { "id": 16777219, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
                            if (!isInitialRender) {
                                Image.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        //京东按钮
                        Button.pop();
                        Row.pop();
                        ListItem.pop();
                    };
                    if (isLazyCreate) {
                        observedShallowRender();
                    }
                    else {
                        observedDeepRender();
                    }
                }
            };
            this.forEachUpdateFunction(elmtId, this.toBuyList, forEachItemGenFunction);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        /*图表部分
        Flex({ direction: FlexDirection.Column, alignItems: ItemAlign.Center, justifyContent: FlexAlign.Center }) {
          Canvas(this.context)
            .width('100%')
            .height('100%')
            .backgroundColor('')
            .onReady(() =>{
              this.offContext.lineWidth = 3;
              this.offContext.beginPath();
              this.offContext.lineCap = 'round';
              this.offContext.lineJoin = 'round';
              this.offContext.strokeStyle = '#ECFFE9';

              this.offContext.moveTo(this.xPos[0], this.yPos[0]);
              let tot = 0;
              for(let i = 0; i<7; i++){
                tot += this.yPos[i];
              }

              //画首个点
              let path: Path2D = new Path2D();
              path.arc(this.xPos[0],60-this.yPos[0]/tot*60,5,0,360);
              this.offContext.fillStyle = '#ECFFE9'
              this.offContext.fill(path);
              //画其余点
              this.offContext.moveTo(this.xPos[0], 60-this.yPos[0]/tot*60);
              for(let i = 1; i<7; i++){
                let path: Path2D = new Path2D();
                path.arc(this.xPos[i],60-this.yPos[i]/tot*60,5,0,360);
                this.offContext.fill(path);
                this.offContext.lineTo(this.xPos[i], 60-this.yPos[i]/tot*60);
                //this.offContext.quadraticCurveTo(this.xPos[i+1],this.yPos[i+1],this.xPos[i+1],this.yPos[i+1])
              }

              this.offContext.stroke();
              var image = this.offContext.transferToImageBitmap();
              this.context.transferFromImageBitmap(image);
            })
        }
        .width('100%')
        .height('8%')
        .position({x:0,y:'10%'})
        图表部分*/
        //待办事项的展示
        List.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //在这里补充界面下方的UI
            Row.create();
            Row.debugLine("pages/toBuyPage.ets(342:9)");
            //在这里补充界面下方的UI
            Row.sharedTransition('sharedImage1', { duration: 500, curve: Curve.Linear });
            //在这里补充界面下方的UI
            Row.position({ x: '50%', y: '100%' });
            if (!isInitialRender) {
                //在这里补充界面下方的UI
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //“添加”按钮：增加记账记录
            Button.createWithChild({ type: ButtonType.Capsule, stateEffect: true });
            Button.debugLine("pages/toBuyPage.ets(344:11)");
            //“添加”按钮：增加记账记录
            Button.width('70vp');
            //“添加”按钮：增加记账记录
            Button.height('70vp');
            //“添加”按钮：增加记账记录
            Button.markAnchor({ x: '35vp', y: 0 });
            //“添加”按钮：增加记账记录
            Button.position({ x: '50%', y: '89%' });
            //“添加”按钮：增加记账记录
            Button.backgroundColor(Color.White);
            //“添加”按钮：增加记账记录
            Button.onClick(() => {
                this.dialogController.open();
                try {
                    //this.isInsert = true;
                    this.newToBuy = new ToBuyData(null, false, null);
                }
                catch (e) {
                    console.info('###' + e);
                }
            });
            if (!isInitialRender) {
                //“添加”按钮：增加记账记录
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ['mainPage_addIcon.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Image.debugLine("pages/toBuyPage.ets(345:13)");
            Image.width('65vp');
            Image.height('65vp');
            Image.fillColor({ "id": 16777219, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //“添加”按钮：增加记账记录
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //左1：明细
            Column.create();
            Column.debugLine("pages/toBuyPage.ets(366:11)");
            //左1：明细
            Column.position({ x: '4%', y: '92%' });
            if (!isInitialRender) {
                //左1：明细
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild({ type: ButtonType.Circle, stateEffect: true });
            Button.debugLine("pages/toBuyPage.ets(367:13)");
            Button.width('40vp');
            Button.height('40vp');
            Button.backgroundColor('#F1F3F5');
            Button.onClick(() => {
                this.jumpDetailPage();
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ['page_detail.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Image.debugLine("pages/toBuyPage.ets(368:15)");
            Image.fillColor(Color.Gray);
            Image.width('35vp');
            Image.height('35vp');
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('明细');
            Text.debugLine("pages/toBuyPage.ets(380:13)");
            Text.fontColor(Color.Black);
            Text.fontSize('15vp');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        //左1：明细
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //左2：统计
            Column.create();
            Column.debugLine("pages/toBuyPage.ets(387:11)");
            //左2：统计
            Column.position({ x: '25%', y: '92%' });
            if (!isInitialRender) {
                //左2：统计
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild({ type: ButtonType.Circle, stateEffect: true });
            Button.debugLine("pages/toBuyPage.ets(388:13)");
            Button.width('40vp');
            Button.height('40vp');
            Button.backgroundColor('#F1F3F5');
            Button.onClick(() => {
                this.jumpSumPage();
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ['page_sum.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Image.debugLine("pages/toBuyPage.ets(389:15)");
            Image.fillColor(Color.Gray);
            Image.width('35vp');
            Image.height('35vp');
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('统计');
            Text.debugLine("pages/toBuyPage.ets(401:13)");
            Text.fontColor(Color.Black);
            Text.fontSize('15vp');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        //左2：统计
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //右1：ToDo List
            Column.create();
            Column.debugLine("pages/toBuyPage.ets(408:11)");
            //右1：ToDo List
            Column.position({ x: '65%', y: '91%' });
            if (!isInitialRender) {
                //右1：ToDo List
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild({ type: ButtonType.Circle, stateEffect: true });
            Button.debugLine("pages/toBuyPage.ets(409:13)");
            Button.width('40vp');
            Button.height('40vp');
            Button.backgroundColor('#F1F3F5');
            Button.onClick(() => {
                this.jumpToBuyPage();
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ['page_tobuy.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Image.debugLine("pages/toBuyPage.ets(410:15)");
            Image.fillColor({ "id": 16777219, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Image.width('40vp');
            Image.height('40vp');
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('清单');
            Text.debugLine("pages/toBuyPage.ets(422:13)");
            Text.fontColor(Color.Black);
            Text.fontSize('15vp');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        //右1：ToDo List
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //左2：我的
            Column.create();
            Column.debugLine("pages/toBuyPage.ets(429:11)");
            //左2：我的
            Column.position({ x: '85%', y: '91%' });
            if (!isInitialRender) {
                //左2：我的
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild({ type: ButtonType.Circle, stateEffect: true });
            Button.debugLine("pages/toBuyPage.ets(430:13)");
            Button.width('40vp');
            Button.height('40vp');
            Button.backgroundColor('#F1F3F5');
            Button.onClick(() => {
                console.info('###Jump to EntryAbility sumPage');
                this.jumpMePage();
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ['page_me.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Image.debugLine("pages/toBuyPage.ets(431:15)");
            Image.fillColor(Color.Gray);
            Image.width('35vp');
            Image.height('35vp');
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('我的');
            Text.debugLine("pages/toBuyPage.ets(444:13)");
            Text.fontColor(Color.Black);
            Text.fontSize('15vp');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        //左2：我的
        Column.pop();
        //在这里补充界面下方的UI
        Row.pop();
        Column.pop();
        Stack.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new ToBuyPage(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=toBuyPage.js.map