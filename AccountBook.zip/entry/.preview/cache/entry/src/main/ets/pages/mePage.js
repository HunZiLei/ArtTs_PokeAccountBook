import router from '@ohos:router';
import CommonConstants from '@bundle:com.example.accountbook/entry/ets/database/CommonConstants';
class MePage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        var _a, _b;
        super(parent, __localStorage, elmtId);
        this.__colorStyle = new ObservedPropertySimplePU('green', this, "colorStyle");
        this.settings = new RenderingContextSettings(true);
        this.context = new CanvasRenderingContext2D(this.settings);
        this.offContext = new OffscreenCanvasRenderingContext2D(600, 600, this.settings);
        this.__xPos = new ObservedPropertyObjectPU(new Array(30, 80, 130, 180, 230, 280, 330), this, "xPos");
        this.__params = new ObservedPropertyObjectPU(router.getParams(), this, "params");
        this.__yPos = new ObservedPropertyObjectPU(((_a = this.params) === null || _a === void 0 ? void 0 : _a['yPos']) ? (_b = this.params) === null || _b === void 0 ? void 0 : _b['yPos'] : new Array(1, 1, 1, 1, 1, 1, 1), this, "yPos");
        this.controller = undefined;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.colorStyle !== undefined) {
            this.colorStyle = params.colorStyle;
        }
        if (params.settings !== undefined) {
            this.settings = params.settings;
        }
        if (params.context !== undefined) {
            this.context = params.context;
        }
        if (params.offContext !== undefined) {
            this.offContext = params.offContext;
        }
        if (params.xPos !== undefined) {
            this.xPos = params.xPos;
        }
        if (params.params !== undefined) {
            this.params = params.params;
        }
        if (params.yPos !== undefined) {
            this.yPos = params.yPos;
        }
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__colorStyle.purgeDependencyOnElmtId(rmElmtId);
        this.__xPos.purgeDependencyOnElmtId(rmElmtId);
        this.__params.purgeDependencyOnElmtId(rmElmtId);
        this.__yPos.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__colorStyle.aboutToBeDeleted();
        this.__xPos.aboutToBeDeleted();
        this.__params.aboutToBeDeleted();
        this.__yPos.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get colorStyle() {
        return this.__colorStyle.get();
    }
    set colorStyle(newValue) {
        this.__colorStyle.set(newValue);
    }
    get xPos() {
        return this.__xPos.get();
    }
    set xPos(newValue) {
        this.__xPos.set(newValue);
    }
    get params() {
        return this.__params.get();
    }
    set params(newValue) {
        this.__params.set(newValue);
    }
    get yPos() {
        return this.__yPos.get();
    }
    set yPos(newValue) {
        this.__yPos.set(newValue);
    }
    /*页面跳转的函数*/
    jumpDetailPage() {
        console.info("###ToBuyPage-yPos: " + this.yPos[0] + "-" + this.yPos[1]);
        router.pushUrl({
            url: 'pages/Index' // 目标url
        }, router.RouterMode.Single, (err) => {
            if (err) {
                console.error(`###Invoke pushUrl failed, code is ${err.code}, message is ${err.message}`);
                return;
            }
            console.info('###Invoke pushUrl succeeded.');
        });
    }
    jumpSumPage() {
        console.info("###ToBuyPage-yPos: " + this.yPos[0] + "-" + this.yPos[1]);
        router.pushUrl({
            url: 'pages/sumPage' // 目标url
        }, router.RouterMode.Single, (err) => {
            if (err) {
                console.error(`###Invoke pushUrl failed, code is ${err.code}, message is ${err.message}`);
                return;
            }
            console.info('###Invoke pushUrl succeeded.');
        });
    }
    jumpToBuyPage() {
        console.info("###ToBuyPage-yPos: " + this.yPos[0] + "-" + this.yPos[1]);
        router.pushUrl({
            url: 'pages/toBuyPage' // 目标url
        }, router.RouterMode.Single, (err) => {
            if (err) {
                console.error(`###Invoke pushUrl failed, code is ${err.code}, message is ${err.message}`);
                return;
            }
            console.info('###Invoke pushUrl succeeded.');
        });
    }
    jumpMePage() {
        router.pushUrl({
            url: 'pages/mePage' // 目标url
        }, router.RouterMode.Single, (err) => {
            if (err) {
                console.error(`###Invoke pushUrl failed, code is ${err.code}, message is ${err.message}`);
                return;
            }
            console.info('###Invoke pushUrl succeeded.');
        });
    }
    /*跳转函数*/
    // /*页面跳转动画*/
    // pageTransition() {
    //   PageTransitionEnter({ duration: 400, curve: Curve.Ease })
    //     .slide(SlideEffect.Left)
    //   PageTransitionExit({ duration: 400, curve: Curve.Ease })
    // }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create();
            Stack.debugLine("pages/mePage.ets(87:5)");
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/mePage.ets(88:7)");
            Column.width('100%');
            Column.height('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //标题 & 编辑按钮
            Row.create();
            Row.debugLine("pages/mePage.ets(90:9)");
            //标题 & 编辑按钮
            Row.sharedTransition('title', { duration: 500, curve: Curve.Linear });
            //标题 & 编辑按钮
            Row.backgroundColor(this.colorStyle == "green" ? { "id": 16777219, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } :
                this.colorStyle == "orange" ? { "id": 16777220, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } :
                    this.colorStyle == "blue" ? { "id": 16777218, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } :
                        this.colorStyle == "purple" ? { "id": 16777221, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } :
                            this.colorStyle == "red" ? { "id": 16777222, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } : { "id": 16777219, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            //标题 & 编辑按钮
            Row.position({ x: 0, y: 0 });
            //标题 & 编辑按钮
            Row.width('100%');
            //标题 & 编辑按钮
            Row.height('20%');
            //标题 & 编辑按钮
            Row.justifyContent(FlexAlign.SpaceBetween);
            if (!isInitialRender) {
                //标题 & 编辑按钮
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create({ "id": 16777257, "type": 10003, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Text.debugLine("pages/mePage.ets(91:11)");
            Text.fontColor(Color.White);
            Text.height(30);
            Text.fontSize(30);
            Text.margin({ left: 24, bottom: '50vp' });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        //标题 & 编辑按钮
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            /*图表部分
            Flex({ direction: FlexDirection.Column, alignItems: ItemAlign.Center, justifyContent: FlexAlign.Center }) {
              Canvas(this.context)
                .width('100%')
                .height('100%')
                .backgroundColor('')
                .onReady(() =>{
                  this.offContext.lineWidth = 3;
                  this.offContext.beginPath();
                  this.offContext.lineCap = 'round';
                  this.offContext.lineJoin = 'round';
                  this.offContext.strokeStyle = '#ECFFE9';
    
                  this.offContext.moveTo(this.xPos[0], this.yPos[0]);
                  let tot = 0;
                  for(let i = 0; i<7; i++){
                    tot += this.yPos[i];
                  }
    
                  //画首个点
                  let path: Path2D = new Path2D();
                  path.arc(this.xPos[0],60-this.yPos[0]/tot*60,5,0,360);
                  this.offContext.fillStyle = '#ECFFE9'
                  this.offContext.fill(path);
                  //画其余点
                  this.offContext.moveTo(this.xPos[0], 60-this.yPos[0]/tot*60);
                  for(let i = 1; i<7; i++){
                    let path: Path2D = new Path2D();
                    path.arc(this.xPos[i],60-this.yPos[i]/tot*60,5,0,360);
                    this.offContext.fill(path);
                    this.offContext.lineTo(this.xPos[i], 60-this.yPos[i]/tot*60);
                    //this.offContext.quadraticCurveTo(this.xPos[i+1],this.yPos[i+1],this.xPos[i+1],this.yPos[i+1])
                  }
    
                  this.offContext.stroke();
                  var image = this.offContext.transferToImageBitmap();
                  this.context.transferFromImageBitmap(image);
                })
            }
            .width('100%')
            .height('8%')
            .position({x:0,y:'10%'})
            图表部分*/
            /*更改颜色的界面*/
            Column.create();
            Column.debugLine("pages/mePage.ets(154:9)");
            /*图表部分
            Flex({ direction: FlexDirection.Column, alignItems: ItemAlign.Center, justifyContent: FlexAlign.Center }) {
              Canvas(this.context)
                .width('100%')
                .height('100%')
                .backgroundColor('')
                .onReady(() =>{
                  this.offContext.lineWidth = 3;
                  this.offContext.beginPath();
                  this.offContext.lineCap = 'round';
                  this.offContext.lineJoin = 'round';
                  this.offContext.strokeStyle = '#ECFFE9';
    
                  this.offContext.moveTo(this.xPos[0], this.yPos[0]);
                  let tot = 0;
                  for(let i = 0; i<7; i++){
                    tot += this.yPos[i];
                  }
    
                  //画首个点
                  let path: Path2D = new Path2D();
                  path.arc(this.xPos[0],60-this.yPos[0]/tot*60,5,0,360);
                  this.offContext.fillStyle = '#ECFFE9'
                  this.offContext.fill(path);
                  //画其余点
                  this.offContext.moveTo(this.xPos[0], 60-this.yPos[0]/tot*60);
                  for(let i = 1; i<7; i++){
                    let path: Path2D = new Path2D();
                    path.arc(this.xPos[i],60-this.yPos[i]/tot*60,5,0,360);
                    this.offContext.fill(path);
                    this.offContext.lineTo(this.xPos[i], 60-this.yPos[i]/tot*60);
                    //this.offContext.quadraticCurveTo(this.xPos[i+1],this.yPos[i+1],this.xPos[i+1],this.yPos[i+1])
                  }
    
                  this.offContext.stroke();
                  var image = this.offContext.transferToImageBitmap();
                  this.context.transferFromImageBitmap(image);
                })
            }
            .width('100%')
            .height('8%')
            .position({x:0,y:'10%'})
            图表部分*/
            /*更改颜色的界面*/
            Column.position({ x: '5%', y: '30%' });
            /*图表部分
            Flex({ direction: FlexDirection.Column, alignItems: ItemAlign.Center, justifyContent: FlexAlign.Center }) {
              Canvas(this.context)
                .width('100%')
                .height('100%')
                .backgroundColor('')
                .onReady(() =>{
                  this.offContext.lineWidth = 3;
                  this.offContext.beginPath();
                  this.offContext.lineCap = 'round';
                  this.offContext.lineJoin = 'round';
                  this.offContext.strokeStyle = '#ECFFE9';
    
                  this.offContext.moveTo(this.xPos[0], this.yPos[0]);
                  let tot = 0;
                  for(let i = 0; i<7; i++){
                    tot += this.yPos[i];
                  }
    
                  //画首个点
                  let path: Path2D = new Path2D();
                  path.arc(this.xPos[0],60-this.yPos[0]/tot*60,5,0,360);
                  this.offContext.fillStyle = '#ECFFE9'
                  this.offContext.fill(path);
                  //画其余点
                  this.offContext.moveTo(this.xPos[0], 60-this.yPos[0]/tot*60);
                  for(let i = 1; i<7; i++){
                    let path: Path2D = new Path2D();
                    path.arc(this.xPos[i],60-this.yPos[i]/tot*60,5,0,360);
                    this.offContext.fill(path);
                    this.offContext.lineTo(this.xPos[i], 60-this.yPos[i]/tot*60);
                    //this.offContext.quadraticCurveTo(this.xPos[i+1],this.yPos[i+1],this.xPos[i+1],this.yPos[i+1])
                  }
    
                  this.offContext.stroke();
                  var image = this.offContext.transferToImageBitmap();
                  this.context.transferFromImageBitmap(image);
                })
            }
            .width('100%')
            .height('8%')
            .position({x:0,y:'10%'})
            图表部分*/
            /*更改颜色的界面*/
            Column.borderWidth({ bottom: CommonConstants.FULL_SIZE });
            /*图表部分
            Flex({ direction: FlexDirection.Column, alignItems: ItemAlign.Center, justifyContent: FlexAlign.Center }) {
              Canvas(this.context)
                .width('100%')
                .height('100%')
                .backgroundColor('')
                .onReady(() =>{
                  this.offContext.lineWidth = 3;
                  this.offContext.beginPath();
                  this.offContext.lineCap = 'round';
                  this.offContext.lineJoin = 'round';
                  this.offContext.strokeStyle = '#ECFFE9';
    
                  this.offContext.moveTo(this.xPos[0], this.yPos[0]);
                  let tot = 0;
                  for(let i = 0; i<7; i++){
                    tot += this.yPos[i];
                  }
    
                  //画首个点
                  let path: Path2D = new Path2D();
                  path.arc(this.xPos[0],60-this.yPos[0]/tot*60,5,0,360);
                  this.offContext.fillStyle = '#ECFFE9'
                  this.offContext.fill(path);
                  //画其余点
                  this.offContext.moveTo(this.xPos[0], 60-this.yPos[0]/tot*60);
                  for(let i = 1; i<7; i++){
                    let path: Path2D = new Path2D();
                    path.arc(this.xPos[i],60-this.yPos[i]/tot*60,5,0,360);
                    this.offContext.fill(path);
                    this.offContext.lineTo(this.xPos[i], 60-this.yPos[i]/tot*60);
                    //this.offContext.quadraticCurveTo(this.xPos[i+1],this.yPos[i+1],this.xPos[i+1],this.yPos[i+1])
                  }
    
                  this.offContext.stroke();
                  var image = this.offContext.transferToImageBitmap();
                  this.context.transferFromImageBitmap(image);
                })
            }
            .width('100%')
            .height('8%')
            .position({x:0,y:'10%'})
            图表部分*/
            /*更改颜色的界面*/
            Column.borderColor('#3348478C');
            /*图表部分
            Flex({ direction: FlexDirection.Column, alignItems: ItemAlign.Center, justifyContent: FlexAlign.Center }) {
              Canvas(this.context)
                .width('100%')
                .height('100%')
                .backgroundColor('')
                .onReady(() =>{
                  this.offContext.lineWidth = 3;
                  this.offContext.beginPath();
                  this.offContext.lineCap = 'round';
                  this.offContext.lineJoin = 'round';
                  this.offContext.strokeStyle = '#ECFFE9';
    
                  this.offContext.moveTo(this.xPos[0], this.yPos[0]);
                  let tot = 0;
                  for(let i = 0; i<7; i++){
                    tot += this.yPos[i];
                  }
    
                  //画首个点
                  let path: Path2D = new Path2D();
                  path.arc(this.xPos[0],60-this.yPos[0]/tot*60,5,0,360);
                  this.offContext.fillStyle = '#ECFFE9'
                  this.offContext.fill(path);
                  //画其余点
                  this.offContext.moveTo(this.xPos[0], 60-this.yPos[0]/tot*60);
                  for(let i = 1; i<7; i++){
                    let path: Path2D = new Path2D();
                    path.arc(this.xPos[i],60-this.yPos[i]/tot*60,5,0,360);
                    this.offContext.fill(path);
                    this.offContext.lineTo(this.xPos[i], 60-this.yPos[i]/tot*60);
                    //this.offContext.quadraticCurveTo(this.xPos[i+1],this.yPos[i+1],this.xPos[i+1],this.yPos[i+1])
                  }
    
                  this.offContext.stroke();
                  var image = this.offContext.transferToImageBitmap();
                  this.context.transferFromImageBitmap(image);
                })
            }
            .width('100%')
            .height('8%')
            .position({x:0,y:'10%'})
            图表部分*/
            /*更改颜色的界面*/
            Column.borderRadius('5vp');
            /*图表部分
            Flex({ direction: FlexDirection.Column, alignItems: ItemAlign.Center, justifyContent: FlexAlign.Center }) {
              Canvas(this.context)
                .width('100%')
                .height('100%')
                .backgroundColor('')
                .onReady(() =>{
                  this.offContext.lineWidth = 3;
                  this.offContext.beginPath();
                  this.offContext.lineCap = 'round';
                  this.offContext.lineJoin = 'round';
                  this.offContext.strokeStyle = '#ECFFE9';
    
                  this.offContext.moveTo(this.xPos[0], this.yPos[0]);
                  let tot = 0;
                  for(let i = 0; i<7; i++){
                    tot += this.yPos[i];
                  }
    
                  //画首个点
                  let path: Path2D = new Path2D();
                  path.arc(this.xPos[0],60-this.yPos[0]/tot*60,5,0,360);
                  this.offContext.fillStyle = '#ECFFE9'
                  this.offContext.fill(path);
                  //画其余点
                  this.offContext.moveTo(this.xPos[0], 60-this.yPos[0]/tot*60);
                  for(let i = 1; i<7; i++){
                    let path: Path2D = new Path2D();
                    path.arc(this.xPos[i],60-this.yPos[i]/tot*60,5,0,360);
                    this.offContext.fill(path);
                    this.offContext.lineTo(this.xPos[i], 60-this.yPos[i]/tot*60);
                    //this.offContext.quadraticCurveTo(this.xPos[i+1],this.yPos[i+1],this.xPos[i+1],this.yPos[i+1])
                  }
    
                  this.offContext.stroke();
                  var image = this.offContext.transferToImageBitmap();
                  this.context.transferFromImageBitmap(image);
                })
            }
            .width('100%')
            .height('8%')
            .position({x:0,y:'10%'})
            图表部分*/
            /*更改颜色的界面*/
            Column.margin({ bottom: '10vp' });
            if (!isInitialRender) {
                /*图表部分
                Flex({ direction: FlexDirection.Column, alignItems: ItemAlign.Center, justifyContent: FlexAlign.Center }) {
                  Canvas(this.context)
                    .width('100%')
                    .height('100%')
                    .backgroundColor('')
                    .onReady(() =>{
                      this.offContext.lineWidth = 3;
                      this.offContext.beginPath();
                      this.offContext.lineCap = 'round';
                      this.offContext.lineJoin = 'round';
                      this.offContext.strokeStyle = '#ECFFE9';
        
                      this.offContext.moveTo(this.xPos[0], this.yPos[0]);
                      let tot = 0;
                      for(let i = 0; i<7; i++){
                        tot += this.yPos[i];
                      }
        
                      //画首个点
                      let path: Path2D = new Path2D();
                      path.arc(this.xPos[0],60-this.yPos[0]/tot*60,5,0,360);
                      this.offContext.fillStyle = '#ECFFE9'
                      this.offContext.fill(path);
                      //画其余点
                      this.offContext.moveTo(this.xPos[0], 60-this.yPos[0]/tot*60);
                      for(let i = 1; i<7; i++){
                        let path: Path2D = new Path2D();
                        path.arc(this.xPos[i],60-this.yPos[i]/tot*60,5,0,360);
                        this.offContext.fill(path);
                        this.offContext.lineTo(this.xPos[i], 60-this.yPos[i]/tot*60);
                        //this.offContext.quadraticCurveTo(this.xPos[i+1],this.yPos[i+1],this.xPos[i+1],this.yPos[i+1])
                      }
        
                      this.offContext.stroke();
                      var image = this.offContext.transferToImageBitmap();
                      this.context.transferFromImageBitmap(image);
                    })
                }
                .width('100%')
                .height('8%')
                .position({x:0,y:'10%'})
                图表部分*/
                /*更改颜色的界面*/
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('UI风格：');
            Text.debugLine("pages/mePage.ets(155:11)");
            Text.margin({ bottom: '12vp' });
            Text.fontSize('35vp');
            Text.fontColor(this.colorStyle == "green" ? { "id": 16777219, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } :
                this.colorStyle == "orange" ? { "id": 16777220, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } :
                    this.colorStyle == "blue" ? { "id": 16777218, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } :
                        this.colorStyle == "purple" ? { "id": 16777221, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } :
                            this.colorStyle == "red" ? { "id": 16777222, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } : { "id": 16777219, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/mePage.ets(166:11)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel({ type: ButtonType.Capsule });
            Button.debugLine("pages/mePage.ets(167:13)");
            Button.width('30vp');
            Button.height('30vp');
            Button.backgroundColor({ "id": 16777219, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Button.margin({ right: '10vp' });
            Button.onClick(() => {
                this.colorStyle = 'green';
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel({ type: ButtonType.Capsule });
            Button.debugLine("pages/mePage.ets(176:13)");
            Button.width('30vp');
            Button.height('30vp');
            Button.backgroundColor({ "id": 16777220, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Button.margin({ right: '10vp' });
            Button.onClick(() => {
                this.colorStyle = 'orange';
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel({ type: ButtonType.Capsule });
            Button.debugLine("pages/mePage.ets(185:13)");
            Button.width('30vp');
            Button.height('30vp');
            Button.backgroundColor({ "id": 16777218, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Button.margin({ right: '10vp' });
            Button.onClick(() => {
                this.colorStyle = 'blue';
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel({ type: ButtonType.Capsule });
            Button.debugLine("pages/mePage.ets(194:13)");
            Button.width('30vp');
            Button.height('30vp');
            Button.backgroundColor({ "id": 16777221, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Button.margin({ right: '10vp' });
            Button.onClick(() => {
                this.colorStyle = 'purple';
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel({ type: ButtonType.Capsule });
            Button.debugLine("pages/mePage.ets(203:13)");
            Button.width('30vp');
            Button.height('30vp');
            Button.backgroundColor({ "id": 16777222, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Button.margin({ right: '10vp' });
            Button.onClick(() => {
                this.colorStyle = 'red';
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Row.pop();
        /*图表部分
        Flex({ direction: FlexDirection.Column, alignItems: ItemAlign.Center, justifyContent: FlexAlign.Center }) {
          Canvas(this.context)
            .width('100%')
            .height('100%')
            .backgroundColor('')
            .onReady(() =>{
              this.offContext.lineWidth = 3;
              this.offContext.beginPath();
              this.offContext.lineCap = 'round';
              this.offContext.lineJoin = 'round';
              this.offContext.strokeStyle = '#ECFFE9';

              this.offContext.moveTo(this.xPos[0], this.yPos[0]);
              let tot = 0;
              for(let i = 0; i<7; i++){
                tot += this.yPos[i];
              }

              //画首个点
              let path: Path2D = new Path2D();
              path.arc(this.xPos[0],60-this.yPos[0]/tot*60,5,0,360);
              this.offContext.fillStyle = '#ECFFE9'
              this.offContext.fill(path);
              //画其余点
              this.offContext.moveTo(this.xPos[0], 60-this.yPos[0]/tot*60);
              for(let i = 1; i<7; i++){
                let path: Path2D = new Path2D();
                path.arc(this.xPos[i],60-this.yPos[i]/tot*60,5,0,360);
                this.offContext.fill(path);
                this.offContext.lineTo(this.xPos[i], 60-this.yPos[i]/tot*60);
                //this.offContext.quadraticCurveTo(this.xPos[i+1],this.yPos[i+1],this.xPos[i+1],this.yPos[i+1])
              }

              this.offContext.stroke();
              var image = this.offContext.transferToImageBitmap();
              this.context.transferFromImageBitmap(image);
            })
        }
        .width('100%')
        .height('8%')
        .position({x:0,y:'10%'})
        图表部分*/
        /*更改颜色的界面*/
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/mePage.ets(219:9)");
            Column.position({ y: '45%' });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('作者：叶磊20215100');
            Text.debugLine("pages/mePage.ets(220:11)");
            Text.fontSize('35bp');
            Text.fontColor(this.colorStyle == "green" ? { "id": 16777219, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } :
                this.colorStyle == "orange" ? { "id": 16777220, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } :
                    this.colorStyle == "blue" ? { "id": 16777218, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } :
                        this.colorStyle == "purple" ? { "id": 16777221, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } :
                            this.colorStyle == "red" ? { "id": 16777222, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } : { "id": 16777219, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Text.margin({ top: '5vp', bottom: '5vp' });
            Text.borderColor(Color.Gray);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/mePage.ets(232:9)");
            Column.position({ y: '60%' });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('产品名：PokeAccountBook\n口袋记账本');
            Text.debugLine("pages/mePage.ets(233:11)");
            Text.width('100%');
            Text.fontSize('35bp');
            Text.fontColor(this.colorStyle == "green" ? { "id": 16777219, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } :
                this.colorStyle == "orange" ? { "id": 16777220, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } :
                    this.colorStyle == "blue" ? { "id": 16777218, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } :
                        this.colorStyle == "purple" ? { "id": 16777221, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } :
                            this.colorStyle == "red" ? { "id": 16777222, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } : { "id": 16777219, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Text.margin({ bottom: '2vp' });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('版本号：v2.1.3');
            Text.debugLine("pages/mePage.ets(242:11)");
            Text.fontSize('15bp');
            Text.fontColor(this.colorStyle == "green" ? { "id": 16777219, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } :
                this.colorStyle == "orange" ? { "id": 16777220, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } :
                    this.colorStyle == "blue" ? { "id": 16777218, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } :
                        this.colorStyle == "purple" ? { "id": 16777221, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } :
                            this.colorStyle == "red" ? { "id": 16777222, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } : { "id": 16777219, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //在这里补充界面下方的UI
            Row.create();
            Row.debugLine("pages/mePage.ets(256:9)");
            //在这里补充界面下方的UI
            Row.sharedTransition('sharedImage1', { duration: 500, curve: Curve.Linear });
            //在这里补充界面下方的UI
            Row.position({ x: '50%', y: '100%' });
            if (!isInitialRender) {
                //在这里补充界面下方的UI
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //“添加”按钮：增加记账记录
            Button.createWithChild({ type: ButtonType.Capsule, stateEffect: true });
            Button.debugLine("pages/mePage.ets(258:11)");
            //“添加”按钮：增加记账记录
            Button.width('70vp');
            //“添加”按钮：增加记账记录
            Button.height('70vp');
            //“添加”按钮：增加记账记录
            Button.markAnchor({ x: '35vp', y: 0 });
            //“添加”按钮：增加记账记录
            Button.position({ x: '50%', y: '89%' });
            //“添加”按钮：增加记账记录
            Button.backgroundColor(Color.White);
            //“添加”按钮：增加记账记录
            Button.onClick(() => {
            });
            if (!isInitialRender) {
                //“添加”按钮：增加记账记录
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ['mainPage_addIcon.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Image.debugLine("pages/mePage.ets(259:13)");
            Image.width('65vp');
            Image.height('65vp');
            Image.fillColor(this.colorStyle == "green" ? { "id": 16777219, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } :
                this.colorStyle == "orange" ? { "id": 16777220, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } :
                    this.colorStyle == "blue" ? { "id": 16777218, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } :
                        this.colorStyle == "purple" ? { "id": 16777221, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } :
                            this.colorStyle == "red" ? { "id": 16777222, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } : { "id": 16777219, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //“添加”按钮：增加记账记录
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //左1：明细
            Column.create();
            Column.debugLine("pages/mePage.ets(277:11)");
            //左1：明细
            Column.position({ x: '4%', y: '92%' });
            if (!isInitialRender) {
                //左1：明细
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild({ type: ButtonType.Circle, stateEffect: true });
            Button.debugLine("pages/mePage.ets(278:13)");
            Button.width('40vp');
            Button.height('40vp');
            Button.backgroundColor('#F1F3F5');
            Button.onClick(() => {
                this.jumpDetailPage();
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ['page_detail.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Image.debugLine("pages/mePage.ets(279:15)");
            Image.fillColor(Color.Gray);
            Image.width('35vp');
            Image.height('35vp');
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('明细');
            Text.debugLine("pages/mePage.ets(291:13)");
            Text.fontColor(Color.Black);
            Text.fontSize('15vp');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        //左1：明细
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //左2：统计
            Column.create();
            Column.debugLine("pages/mePage.ets(298:11)");
            //左2：统计
            Column.position({ x: '25%', y: '92%' });
            if (!isInitialRender) {
                //左2：统计
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild({ type: ButtonType.Circle, stateEffect: true });
            Button.debugLine("pages/mePage.ets(299:13)");
            Button.width('40vp');
            Button.height('40vp');
            Button.backgroundColor('#F1F3F5');
            Button.onClick(() => {
                this.jumpSumPage();
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ['page_sum.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Image.debugLine("pages/mePage.ets(300:15)");
            Image.fillColor(Color.Gray);
            Image.width('35vp');
            Image.height('35vp');
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('统计');
            Text.debugLine("pages/mePage.ets(312:13)");
            Text.fontColor(Color.Black);
            Text.fontSize('15vp');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        //左2：统计
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //右1：ToDo List
            Column.create();
            Column.debugLine("pages/mePage.ets(321:11)");
            //右1：ToDo List
            Column.position({ x: '65%', y: '91%' });
            if (!isInitialRender) {
                //右1：ToDo List
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild({ type: ButtonType.Circle, stateEffect: true });
            Button.debugLine("pages/mePage.ets(322:13)");
            Button.width('40vp');
            Button.height('40vp');
            Button.backgroundColor('#F1F3F5');
            Button.onClick(() => {
                this.jumpToBuyPage();
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ['page_tobuy.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Image.debugLine("pages/mePage.ets(323:15)");
            Image.fillColor(Color.Gray);
            Image.width('40vp');
            Image.height('40vp');
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('清单');
            Text.debugLine("pages/mePage.ets(335:13)");
            Text.fontColor(Color.Black);
            Text.fontSize('15vp');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        //右1：ToDo List
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //左2：我的
            Column.create();
            Column.debugLine("pages/mePage.ets(342:11)");
            //左2：我的
            Column.position({ x: '85%', y: '91%' });
            if (!isInitialRender) {
                //左2：我的
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild({ type: ButtonType.Circle, stateEffect: true });
            Button.debugLine("pages/mePage.ets(343:13)");
            Button.width('40vp');
            Button.height('40vp');
            Button.backgroundColor('#F1F3F5');
            Button.onClick(() => {
                console.info('###Jump to EntryAbility sumPage');
                this.jumpMePage();
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ['page_me.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Image.debugLine("pages/mePage.ets(344:15)");
            Image.fillColor(this.colorStyle == "green" ? { "id": 16777219, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } :
                this.colorStyle == "orange" ? { "id": 16777220, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } :
                    this.colorStyle == "blue" ? { "id": 16777218, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } :
                        this.colorStyle == "purple" ? { "id": 16777221, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } :
                            this.colorStyle == "red" ? { "id": 16777222, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } : { "id": 16777219, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Image.width('35vp');
            Image.height('35vp');
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('我的');
            Text.debugLine("pages/mePage.ets(361:13)");
            Text.fontColor(Color.Black);
            Text.fontSize('15vp');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        //左2：我的
        Column.pop();
        //在这里补充界面下方的UI
        Row.pop();
        Column.pop();
        Stack.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new MePage(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=mePage.js.map