export default class ToBuyData {
    constructor(name, isDone, date) {
        this.thing = 'default';
        this.isDone = false;
        this.thing = name;
        this.isDone = isDone;
        this.ddl = date;
    }
}
//# sourceMappingURL=ToBuyData.js.map