import hilog from '@ohos:hilog';
import formBindingData from '@ohos:app.form.formBindingData';
import FormExtensionAbility from '@ohos:app.form.FormExtensionAbility';
import formProvider from '@ohos:app.form.formProvider';
let selectPage = "";
let currentWindowStage = null;
export default class EntryAbility extends FormExtensionAbility {
    /*在这里对目标页面进行调整*/
    onCreate(want, launchParam) {
        hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onCreate');
        if (want.parameters.params !== undefined) {
            let params = JSON.parse(want.parameters.params);
            console.info("onCreate router targetPage:" + params.targetPage);
            selectPage = params.targetPage;
        }
    }
    // 如果UIAbility已在后台运行，在收到Router事件后会触发onNewWant生命周期回调
    onNewWant(want, launchParam) {
        var _a, _b;
        console.info("onNewWant want:" + JSON.stringify(want));
        if (((_a = want.parameters) === null || _a === void 0 ? void 0 : _a.params) !== undefined) {
            let params = JSON.parse((_b = want.parameters) === null || _b === void 0 ? void 0 : _b.params.toString());
            console.info("onNewWant router targetPage:" + params.targetPage);
            selectPage = params.targetPage;
        }
        if (currentWindowStage != null) {
            this.onWindowStageCreate(currentWindowStage);
        }
    }
    onWindowStageCreate(windowStage) {
        let targetPage;
        // 根据传递的targetPage不同，选择拉起不同的页面
        switch (selectPage) {
            case 'sumPage':
                targetPage = 'pages/sumPage';
                break;
            case 'detailPage':
                targetPage = 'pages/Index';
                break;
            default:
                targetPage = 'pages/Index';
        }
        if (currentWindowStage === null) {
            currentWindowStage = windowStage;
        }
        windowStage.loadContent(targetPage, (err, data) => {
            if (err && err.code) {
                console.info('###Failed to load the content. Cause: %{public}s', JSON.stringify(err));
                return;
            }
        });
    }
    /*以上是页面跳转的部分*/
    onDestroy() {
        hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onDestroy');
    }
    onWindowStageDestroy() {
        // Main window is destroyed, release UI related resources
        hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onWindowStageDestroy');
    }
    onForeground() {
        // Ability has brought to foreground
        hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onForeground');
    }
    onBackground() {
        // Ability has back to background
        hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onBackground');
    }
    onFormEvent(formId, message) {
        // Called when a specified message event defined by the form provider is triggered.
        // 若卡片支持触发事件，则需要重写该方法并实现对事件的触发
        let formData = {
            'title': 'Poke AccountBook',
        };
        console.info("###FormID: " + formId + " || " + "message: " + (message === null || message === void 0 ? void 0 : message['newCurve']));
        let formInfo = formBindingData.createFormBindingData(formData);
        formProvider.updateForm(formId, formInfo).then((data) => {
            console.info('FormAbility updateForm success.' + JSON.stringify(data));
        }).catch((error) => {
            console.error('FormAbility updateForm failed: ' + JSON.stringify(error));
        });
        console.info('####[EntryFormAbility] onFormEvent');
    }
}
//# sourceMappingURL=EntryAbility.js.map