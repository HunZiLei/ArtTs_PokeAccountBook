export const PayList = [
    {
        icon: { "id": 0, "type": 30000, params: ['foods.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        iconSelected: { "id": 0, "type": 30000, params: ['foods.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        accountType: 0,
        typeText: '吃饭'
    },
    {
        icon: { "id": 0, "type": 30000, params: ['snacks.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        iconSelected: { "id": 0, "type": 30000, params: ['snacks.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        accountType: 0,
        typeText: '零食'
    },
    {
        icon: { "id": 0, "type": 30000, params: ['fuel.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        iconSelected: { "id": 0, "type": 30000, params: ['fuel.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        accountType: 0,
        typeText: '汽车加油'
    },
    {
        icon: { "id": 0, "type": 30000, params: ['travel.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        iconSelected: { "id": 0, "type": 30000, params: ['travel.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        accountType: 0,
        typeText: '旅游'
    },
    {
        icon: { "id": 0, "type": 30000, params: ['games.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        iconSelected: { "id": 0, "type": 30000, params: ['games.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        accountType: 0,
        typeText: '娱乐'
    },
    {
        icon: { "id": 0, "type": 30000, params: ['pets.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        iconSelected: { "id": 0, "type": 30000, params: ['pets.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        accountType: 0,
        typeText: '宠物'
    },
    {
        icon: { "id": 0, "type": 30000, params: ['competition.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        iconSelected: { "id": 0, "type": 30000, params: ['competition.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        accountType: 0,
        typeText: '竞赛'
    },
    {
        icon: { "id": 0, "type": 30000, params: ['digit.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        iconSelected: { "id": 0, "type": 30000, params: ['digit.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        accountType: 0,
        typeText: '数码'
    },
    {
        icon: { "id": 0, "type": 30000, params: ['festival.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        iconSelected: { "id": 0, "type": 30000, params: ['festival.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        accountType: 0,
        typeText: '节日'
    },
    {
        icon: { "id": 0, "type": 30000, params: ['gift.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        iconSelected: { "id": 0, "type": 30000, params: ['gift.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        accountType: 0,
        typeText: '礼物'
    },
    {
        icon: { "id": 0, "type": 30000, params: ['sneaker.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        iconSelected: { "id": 0, "type": 30000, params: ['sneaker.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        accountType: 0,
        typeText: '鞋子'
    },
    {
        icon: { "id": 0, "type": 30000, params: ['fruit.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        iconSelected: { "id": 0, "type": 30000, params: ['fruit.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        accountType: 0,
        typeText: '水果'
    },
    {
        icon: { "id": 0, "type": 30000, params: ['workout.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        iconSelected: { "id": 0, "type": 30000, params: ['workout.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        accountType: 0,
        typeText: '健身'
    },
    {
        icon: { "id": 0, "type": 30000, params: ['PE.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        iconSelected: { "id": 0, "type": 30000, params: ['PE.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        accountType: 0,
        typeText: '运动'
    },
    {
        icon: { "id": 0, "type": 30000, params: ['badminton.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        iconSelected: { "id": 0, "type": 30000, params: ['badminton.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        accountType: 0,
        typeText: '羽毛球'
    },
    {
        icon: { "id": 0, "type": 30000, params: ['social.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        iconSelected: { "id": 0, "type": 30000, params: ['social.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        accountType: 0,
        typeText: '社交'
    }
];
export const EarnList = [
    {
        icon: { "id": 0, "type": 30000, params: ['income.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        iconSelected: { "id": 0, "type": 30000, params: ['income.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        accountType: 1,
        typeText: '工作收入'
    },
    {
        icon: { "id": 0, "type": 30000, params: ['invest.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        iconSelected: { "id": 0, "type": 30000, params: ['invest.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        accountType: 1,
        typeText: '投资'
    },
    {
        icon: { "id": 0, "type": 30000, params: ['awards.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        iconSelected: { "id": 0, "type": 30000, params: ['awards.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        accountType: 1,
        typeText: '奖金'
    },
    {
        icon: { "id": 0, "type": 30000, params: ['extraIncome.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        iconSelected: { "id": 0, "type": 30000, params: ['extraIncome.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
        accountType: 1,
        typeText: '外快'
    }
];
export const ImageList = {
    '吃饭': { "id": 0, "type": 30000, params: ['foods.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
    '零食': { "id": 0, "type": 30000, params: ['snacks.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
    '汽车加油': { "id": 0, "type": 30000, params: ['fuel.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
    '旅游': { "id": 0, "type": 30000, params: ['travel.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
    '娱乐': { "id": 0, "type": 30000, params: ['games.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
    '宠物': { "id": 0, "type": 30000, params: ['pets.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
    '竞赛': { "id": 0, "type": 30000, params: ['competition.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
    '数码': { "id": 0, "type": 30000, params: ['digit.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
    '节日': { "id": 0, "type": 30000, params: ['festival.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
    '礼物': { "id": 0, "type": 30000, params: ['gift.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
    '鞋子': { "id": 0, "type": 30000, params: ['sneaker.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
    '水果': { "id": 0, "type": 30000, params: ['fruit.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
    '健身': { "id": 0, "type": 30000, params: ['workout.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
    '运动': { "id": 0, "type": 30000, params: ['PE.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
    '羽毛球': { "id": 0, "type": 30000, params: ['badminton.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
    '社交': { "id": 0, "type": 30000, params: ['social.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
    '工作收入': { "id": 0, "type": 30000, params: ['income.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
    '投资': { "id": 0, "type": 30000, params: ['invest.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
    '奖金': { "id": 0, "type": 30000, params: ['awards.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" },
    '外快': { "id": 0, "type": 30000, params: ['extraIncome.svg'], "bundleName": "com.example.accountbook", "moduleName": "entry" }
};
//# sourceMappingURL=AccountList.js.map