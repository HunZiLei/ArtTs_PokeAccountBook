/*
 * Copyright (c) 2023 Huawei Device Co., Ltd.
 * Licensed under the Apache License,Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import prompt from '@ohos:promptAction';
import CommonConstants from '@bundle:com.example.accountbook/entry/ets/database/CommonConstants';
export class toBuyDialog extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.controller = undefined;
        this.__isInsert = new SynchedPropertySimpleTwoWayPU(params.isInsert, this, "isInsert");
        this.__newToBuy = new SynchedPropertyObjectTwoWayPU(params.newToBuy, this, "newToBuy");
        this.confirm = undefined;
        this.inputThing = '';
        this.__timeSelected = new ObservedPropertySimplePU('今天', this, "timeSelected");
        this.selected_date = undefined;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
        if (params.confirm !== undefined) {
            this.confirm = params.confirm;
        }
        if (params.inputThing !== undefined) {
            this.inputThing = params.inputThing;
        }
        if (params.timeSelected !== undefined) {
            this.timeSelected = params.timeSelected;
        }
        if (params.selected_date !== undefined) {
            this.selected_date = params.selected_date;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__isInsert.purgeDependencyOnElmtId(rmElmtId);
        this.__newToBuy.purgeDependencyOnElmtId(rmElmtId);
        this.__timeSelected.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__isInsert.aboutToBeDeleted();
        this.__newToBuy.aboutToBeDeleted();
        this.__timeSelected.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    setController(ctr) {
        this.controller = ctr;
    }
    get isInsert() {
        return this.__isInsert.get();
    }
    set isInsert(newValue) {
        this.__isInsert.set(newValue);
    }
    get newToBuy() {
        return this.__newToBuy.get();
    }
    set newToBuy(newValue) {
        this.__newToBuy.set(newValue);
    }
    get timeSelected() {
        return this.__timeSelected.get();
    }
    set timeSelected(newValue) {
        this.__timeSelected.set(newValue);
    }
    getRealDate(date) {
        return date.getFullYear().toString() + '-' + (date.getMonth() + 1).toString() + '-' + date.getDate().toString();
    }
    TabBuilder(index, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/toBuyDialog.ets(43:5)");
            Column.width('48vp');
            Column.padding({ top: '17vp', bottom: '8vp' });
            Column.margin({ bottom: '8vp' });
            Column.border({
                width: { bottom: '2vp' },
                color: '#018F90'
            });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('待购清单');
            Text.debugLine("pages/toBuyDialog.ets(44:7)");
            Text.fontSize('16vp');
            Text.fontColor('#018F90');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/toBuyDialog.ets(58:5)");
            Column.width(CommonConstants.FULL_WIDTH);
            Column.height(CommonConstants.DIALOG_HEIGHT);
            Column.borderRadius({ topLeft: { "id": 16777246, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" }, topRight: { "id": 16777246, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } });
            Column.backgroundColor(Color.White);
            Column.align(Alignment.BottomEnd);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //取消栏
            Image.create({ "id": 0, "type": 30000, params: ['half.png'], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Image.debugLine("pages/toBuyDialog.ets(60:7)");
            //取消栏
            Image.width('64vp');
            //取消栏
            Image.height('24vp');
            //取消栏
            Image.onClick(() => {
                var _a;
                (_a = this.controller) === null || _a === void 0 ? void 0 : _a.close();
            });
            if (!isInitialRender) {
                //取消栏
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //日期和时间
            Column.create();
            Column.debugLine("pages/toBuyDialog.ets(68:7)");
            if (!isInitialRender) {
                //日期和时间
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('截止时间');
            Text.debugLine("pages/toBuyDialog.ets(69:9)");
            Text.width('100%');
            Text.fontSize('20vp');
            Text.fontColor(Color.Black);
            Text.padding({ left: { "id": 16777240, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" }, right: { "id": 16777240, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" }, top: '5vp' });
            Text.margin({ bottom: '5vp' });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/toBuyDialog.ets(76:9)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //今天
            Text.create('今天');
            Text.debugLine("pages/toBuyDialog.ets(78:11)");
            //今天
            Text.onClick(() => {
                this.timeSelected = '今天';
                this.newToBuy.ddl = new Date();
            });
            //今天
            Text.fontColor(Color.White);
            //今天
            Text.fontSize('25vp');
            //今天
            Text.backgroundColor(this.timeSelected == '今天' ? { "id": 16777219, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } : '#C3C3C3');
            //今天
            Text.margin({ right: '5vp' });
            if (!isInitialRender) {
                //今天
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //今天
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //明天
            Text.create('明天');
            Text.debugLine("pages/toBuyDialog.ets(89:11)");
            //明天
            Text.fontColor(Color.White);
            //明天
            Text.fontSize('25vp');
            //明天
            Text.onClick(() => {
                this.timeSelected = '明天';
                this.newToBuy.ddl = new Date();
            });
            //明天
            Text.backgroundColor(this.timeSelected == '明天' ? { "id": 16777219, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } : '#C3C3C3');
            //明天
            Text.margin({ right: '5vp' });
            if (!isInitialRender) {
                //明天
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //明天
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //自己选时间
            Text.create(this.getRealDate(this.newToBuy.ddl === null ? new Date() : this.newToBuy.ddl));
            Text.debugLine("pages/toBuyDialog.ets(100:11)");
            //自己选时间
            Text.fontColor(Color.White);
            //自己选时间
            Text.fontSize('25vp');
            //自己选时间
            Text.onClick(() => {
                this.timeSelected = '任意';
                let cur_date = new Date();
                this.selected_date = cur_date;
                DatePickerDialog.show({
                    start: new Date("2022-1-1"),
                    end: new Date("2024-1-1"),
                    selected: this.selected_date,
                    //确认时
                    onAccept: (value) => {
                        this.selected_date.setFullYear(value.year, value.month, value.day);
                        this.newToBuy.ddl = new Date(value.year.toString() + '-' + (value.month + 1).toString() + '-' + value.day.toString() + '-');
                    }
                });
            });
            //自己选时间
            Text.backgroundColor(this.timeSelected == '任意' ? { "id": 16777219, "type": 10001, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } : '#C3C3C3');
            if (!isInitialRender) {
                //自己选时间
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //自己选时间
        Text.pop();
        Row.pop();
        //日期和时间
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Blank.create();
            Blank.debugLine("pages/toBuyDialog.ets(122:7)");
            Blank.layoutWeight(1);
            if (!isInitialRender) {
                Blank.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Blank.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //商品
            Column.create();
            Column.debugLine("pages/toBuyDialog.ets(126:7)");
            //商品
            Column.width(CommonConstants.FULL_WIDTH);
            //商品
            Column.padding({ left: { "id": 16777240, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" }, right: { "id": 16777240, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" } });
            if (!isInitialRender) {
                //商品
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('商品');
            Text.debugLine("pages/toBuyDialog.ets(127:9)");
            Text.width(CommonConstants.FULL_WIDTH);
            Text.fontSize({ "id": 16777248, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Text.fontColor(Color.Black);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({
                placeholder: '准备买什么...',
                text: this.newToBuy.thing === '' ? this.inputThing : this.newToBuy.thing
            });
            TextInput.debugLine("pages/toBuyDialog.ets(132:9)");
            TextInput.padding({ left: CommonConstants.MINIMUM_SIZE });
            TextInput.borderRadius(CommonConstants.MINIMUM_SIZE);
            TextInput.backgroundColor(Color.White);
            TextInput.type(InputType.Normal);
            TextInput.onChange((value) => {
                this.inputThing = value;
                this.newToBuy.thing = this.inputThing;
            });
            TextInput.onSubmit(() => {
                this.newToBuy.thing = this.inputThing;
            });
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //商品
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Blank.create();
            Blank.debugLine("pages/toBuyDialog.ets(151:7)");
            Blank.layoutWeight(4);
            if (!isInitialRender) {
                Blank.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Blank.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //确定
            Column.create();
            Column.debugLine("pages/toBuyDialog.ets(155:7)");
            //确定
            Column.layoutWeight(CommonConstants.FULL_SIZE);
            //确定
            Column.padding({
                bottom: { "id": 16777246, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" },
                left: { "id": 16777246, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" },
                right: { "id": 16777246, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" }
            });
            //确定
            Column.justifyContent(FlexAlign.End);
            if (!isInitialRender) {
                //确定
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild();
            Button.debugLine("pages/toBuyDialog.ets(156:9)");
            Button.width(CommonConstants.FULL_WIDTH);
            Button.height({ "id": 16777232, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Button.onClick(() => {
                var _a;
                if (this.newToBuy.thing === '') {
                    prompt.showToast({ message: CommonConstants.TOAST_NULL_BUY, bottom: CommonConstants.PROMPT_BOTTOM });
                }
                else {
                    this.confirm && this.confirm(this.isInsert, ObservedObject.GetRawObject(this.newToBuy));
                    (_a = this.controller) === null || _a === void 0 ? void 0 : _a.close();
                }
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create({ "id": 16777262, "type": 10003, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Text.debugLine("pages/toBuyDialog.ets(157:11)");
            Text.fontSize({ "id": 16777247, "type": 10002, params: [], "bundleName": "com.example.accountbook", "moduleName": "entry" });
            Text.fontColor(Color.White);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Button.pop();
        //确定
        Column.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=toBuyDialog.js.map